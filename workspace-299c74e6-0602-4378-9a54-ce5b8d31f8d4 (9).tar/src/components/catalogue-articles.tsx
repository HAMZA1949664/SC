"use client";

/**
 * Espace de travail « Articles » — base de données complète du catalogue,
 * réservé au service Achats (rôle « achats »). Consultation de TOUTES les
 * références (article, couleur, manche, taille, code-barres) avec AJOUT de
 * nouvelles lignes — volontairement SANS aucune suppression : le catalogue
 * ne peut que grossir, les codes déjà produits restent valides pour toujours.
 */

import { useCallback, useEffect, useMemo, useState } from "react";
import {
  Database,
  Loader2,
  Lock,
  Plus,
  RefreshCw,
  Search,
} from "lucide-react";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { couleurLabel, ean13CheckDigit, mancheLabel } from "@/lib/label-data";

/** Ligne catalogue telle que renvoyée par /api/articles. */
type LigneArticle = [article: string, couleur: string, taille: string, manche: string, codeBarre: string];

/** Nombre de lignes rendues initialement (le catalogue peut dépasser 4 000 références). */
const PAS_AFFICHAGE = 200;

/** Valeurs de manche admises (identiques au catalogue existant). */
const VALEURS_MANCHE = [
  { value: "", label: "Sans manche" },
  { value: "Longues / Long", label: "Manches longues" },
  { value: "Courtes / Short", label: "Manches courtes" },
  { value: "3/4 / 3/4", label: "Manches 3/4" },
];

interface PropsCatalogueArticles {
  /** Appelé après chaque ajout réussi (rafraîchit le catalogue du formulaire). */
  onAjoute?: () => void;
}

export function CatalogueArticles({ onAjoute }: PropsCatalogueArticles) {
  const { toast } = useToast();

  // ----- Données -----
  const [lignes, setLignes] = useState<LigneArticle[]>([]);
  const [chargement, setChargement] = useState(true);
  const [erreur, setErreur] = useState<string | null>(null);
  const [recherche, setRecherche] = useState("");
  const [nbAffichees, setNbAffichees] = useState(PAS_AFFICHAGE);

  // ----- Formulaire d'ajout -----
  const [nouvelArticle, setNouvelArticle] = useState("");
  const [nouvelleCouleur, setNouvelleCouleur] = useState("");
  const [nouvelleManche, setNouvelleManche] = useState("");
  const [nouvelleTaille, setNouvelleTaille] = useState("");
  const [nouveauCode, setNouveauCode] = useState("");
  const [ajoutEnCours, setAjoutEnCours] = useState(false);

  /** Charge le catalogue complet (même API que le générateur d'étiquettes). */
  const charger = useCallback(async () => {
    setChargement(true);
    setErreur(null);
    try {
      const res = await fetch("/api/articles", { cache: "no-store" });
      if (!res.ok) throw new Error(`Erreur ${res.status}`);
      const data = (await res.json()) as { records?: LigneArticle[] };
      setLignes(Array.isArray(data.records) ? data.records : []);
    } catch {
      setErreur("Impossible de charger la base de données articles. Réessayez.");
    } finally {
      setChargement(false);
    }
  }, []);

  useEffect(() => {
    charger();
  }, [charger]);

  /** Recherche insensible à la casse sur toutes les colonnes (+ libellé couleur). */
  const lignesFiltrees = useMemo(() => {
    const q = recherche.trim().toLowerCase();
    if (!q) return lignes;
    return lignes.filter((l) => {
      const [article, couleur, taille, manche, code] = l;
      return (
        article.toLowerCase().includes(q) ||
        couleur.toLowerCase().includes(q) ||
        couleurLabel(couleur)[0].toLowerCase().includes(q) ||
        taille.toLowerCase().includes(q) ||
        manche.toLowerCase().includes(q) ||
        mancheLabel(manche)?.[0]?.toLowerCase().includes(q) ||
        code.includes(q)
      );
    });
  }, [lignes, recherche]);

  const affichees = useMemo(
    () => lignesFiltrees.slice(0, nbAffichees),
    [lignesFiltrees, nbAffichees]
  );

  /** Code-barres complété : 12 chiffres → clé de contrôle calculée automatiquement. */
  const codeFinal = useMemo(() => {
    const brut = nouveauCode.replace(/\s+/g, "");
    if (/^\d{12}$/.test(brut)) return brut + ean13CheckDigit(brut);
    return brut;
  }, [nouveauCode]);

  const codeValide = /^\d{13}$/.test(codeFinal) && ean13CheckDigit(codeFinal.slice(0, 12)) === codeFinal[12];
  const formulaireComplet =
    nouvelArticle.trim() !== "" &&
    nouvelleCouleur.trim() !== "" &&
    nouvelleTaille.trim() !== "" &&
    codeValide &&
    !ajoutEnCours;

  /** Aperçu en direct de la clé calculée (aide à la saisie). */
  const indiceCode = useMemo(() => {
    const brut = nouveauCode.replace(/\s+/g, "");
    if (/^\d{12}$/.test(brut)) return `Clé calculée : ${ean13CheckDigit(brut)} → ${codeFinal}`;
    if (/^\d{13}$/.test(brut)) {
      const attendu = ean13CheckDigit(brut.slice(0, 12));
      return attendu === brut[12]
        ? "Code EAN-13 valide ✓"
        : `Clé de contrôle incorrecte (attendue : ${attendu})`;
    }
    return null;
  }, [nouveauCode, codeFinal]);

  /** Ajout d'une ligne : POST /api/articles (ajout seul — jamais de suppression). */
  async function ajouterLigne() {
    if (!formulaireComplet) return;
    setAjoutEnCours(true);
    try {
      const res = await fetch("/api/articles", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          article: nouvelArticle.trim(),
          couleur: nouvelleCouleur.trim().toUpperCase(),
          taille: nouvelleTaille.trim().toUpperCase(),
          manche: nouvelleManche,
          codeBarre: codeFinal,
        }),
      });
      const data = (await res.json().catch(() => ({}))) as { error?: string };
      if (!res.ok) {
        toast({
          variant: "destructive",
          title: "Ajout refusé",
          description: data.error ?? "Erreur inconnue.",
        });
        return;
      }
      toast({
        title: "Référence ajoutée",
        description: `${nouvelArticle.trim()} — ${nouvelleTaille.trim().toUpperCase()} (${codeFinal}) rejoint le catalogue.`,
      });
      setNouvelArticle("");
      setNouvelleCouleur("");
      setNouvelleManche("");
      setNouvelleTaille("");
      setNouveauCode("");
      await charger();
      onAjoute?.();
    } catch {
      toast({
        variant: "destructive",
        title: "Ajout impossible",
        description: "Le serveur n'a pas répondu. Vérifiez la connexion.",
      });
    } finally {
      setAjoutEnCours(false);
    }
  }

  return (
    <div className="space-y-6">
      {/* ------------------------- Formulaire d'ajout ------------------------- */}
      <Card className="card-lift">
        <CardHeader className="pb-4">
          <CardTitle className="flex flex-wrap items-center justify-between gap-x-2 gap-y-1.5 text-base">
            <span className="flex min-w-0 items-center gap-2">
              <Plus className="h-4 w-4 shrink-0 text-amber-600" aria-hidden="true" />
              Ajouter une référence au catalogue
            </span>
            <Badge variant="outline" className="gap-1 border-emerald-300 bg-emerald-50 text-emerald-800 dark:border-emerald-500/40 dark:bg-emerald-950/30 dark:text-emerald-300">
              <Lock className="h-3 w-3" aria-hidden="true" />
              Ajout seul — aucune suppression
            </Badge>
          </CardTitle>
          <CardDescription>
            La ligne rejoint immédiatement la base partagée : sélectionnable dans
            le générateur d&apos;étiquettes, le colisage et les réceptions. Les
            codes déjà produits ne sont jamais retirés.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            <div className="space-y-2">
              <Label htmlFor="cat-article">Article *</Label>
              <Input
                id="cat-article"
                value={nouvelArticle}
                onChange={(e) => setNouvelArticle(e.target.value)}
                placeholder="ex. FIRENZE"
                maxLength={60}
                className="h-11 uppercase"
                autoComplete="off"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="cat-couleur">Couleur (code stock) *</Label>
              <Input
                id="cat-couleur"
                value={nouvelleCouleur}
                onChange={(e) => setNouvelleCouleur(e.target.value)}
                placeholder="ex. BLC"
                maxLength={20}
                className="h-11 uppercase"
                autoComplete="off"
              />
            </div>
            <div className="space-y-2">
              <Label>Manche</Label>
              <Select value={nouvelleManche || "sans"} onValueChange={(v) => setNouvelleManche(v === "sans" ? "" : v)}>
                <SelectTrigger className="h-11 w-full" aria-label="Manche">
                  <SelectValue placeholder="Choisir…" />
                </SelectTrigger>
                <SelectContent>
                  {VALEURS_MANCHE.map((m) => (
                    <SelectItem key={m.value || "sans"} value={m.value || "sans"}>
                      {m.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="cat-taille">Taille *</Label>
              <Input
                id="cat-taille"
                value={nouvelleTaille}
                onChange={(e) => setNouvelleTaille(e.target.value)}
                placeholder="ex. T46"
                maxLength={20}
                className="h-11 uppercase"
                autoComplete="off"
              />
            </div>
            <div className="space-y-2 sm:col-span-2">
              <Label htmlFor="cat-code">Code-barres EAN-13 * (12 chiffres = clé calculée)</Label>
              <Input
                id="cat-code"
                value={nouveauCode}
                onChange={(e) => setNouveauCode(e.target.value.replace(/[^\d]/g, "").slice(0, 13))}
                inputMode="numeric"
                placeholder="ex. 3700791711730"
                className="h-11 font-mono"
                autoComplete="off"
              />
              {indiceCode && (
                <p
                  className={`text-[11px] ${
                    codeValide
                      ? "text-emerald-700 dark:text-emerald-400"
                      : "text-amber-700 dark:text-amber-400"
                  }`}
                >
                  {indiceCode}
                </p>
              )}
            </div>
          </div>
        </CardContent>
        <CardFooter className="border-t bg-zinc-50/60 dark:bg-zinc-900/60">
          <Button onClick={ajouterLigne} disabled={!formulaireComplet} className="h-11 w-full sm:w-auto">
            {ajoutEnCours ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" aria-hidden="true" />
            ) : (
              <Plus className="mr-2 h-4 w-4" aria-hidden="true" />
            )}
            {ajoutEnCours ? "Ajout en cours…" : "Ajouter la ligne"}
          </Button>
        </CardFooter>
      </Card>

      {/* ------------------------- Tableau complet ------------------------- */}
      <Card className="card-lift">
        <CardHeader className="pb-4">
          <CardTitle className="flex items-center justify-between gap-2 text-base">
            <span className="flex items-center gap-2">
              <Database className="h-4 w-4 text-amber-600" aria-hidden="true" />
              Base de données articles
            </span>
            <span className="flex items-center gap-2">
              <Badge variant="secondary">
                {chargement
                  ? "Chargement…"
                  : `${lignesFiltrees.length.toLocaleString("fr-FR")} référence${lignesFiltrees.length > 1 ? "s" : ""}`}
              </Badge>
              <Button
                variant="ghost"
                size="icon"
                aria-label="Rafraîchir la base de données articles"
                onClick={charger}
                className="h-8 w-8"
              >
                <RefreshCw className={`h-4 w-4 ${chargement ? "animate-spin" : ""}`} aria-hidden="true" />
              </Button>
            </span>
          </CardTitle>
          <CardDescription>
            Toutes les références du stock : article, couleur, manche, taille et
            code-barres. Recherchez sur n&apos;importe quelle colonne.
          </CardDescription>
          <div className="relative pt-1">
            <Search
              className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground"
              aria-hidden="true"
            />
            <Input
              value={recherche}
              onChange={(e) => {
                setRecherche(e.target.value);
                setNbAffichees(PAS_AFFICHAGE);
              }}
              placeholder="Rechercher un article, une couleur, une taille, un code-barres…"
              className="h-11 pl-9"
              aria-label="Rechercher dans la base de données articles"
            />
          </div>
        </CardHeader>
        <CardContent>
          {erreur ? (
            <div className="flex flex-col items-center gap-3 py-8 text-center">
              <p className="text-sm text-red-700 dark:text-red-400">{erreur}</p>
              <Button variant="outline" size="sm" onClick={charger}>
                <RefreshCw className="mr-2 h-4 w-4" aria-hidden="true" />
                Réessayer
              </Button>
            </div>
          ) : chargement ? (
            <div className="flex items-center justify-center gap-2 py-10 text-sm text-muted-foreground">
              <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
              Chargement du catalogue…
            </div>
          ) : lignesFiltrees.length === 0 ? (
            <p className="py-10 text-center text-sm text-muted-foreground">
              {lignes.length === 0
                ? "Le catalogue est vide : ajoutez la première référence ci-dessus."
                : "Aucune référence ne correspond à la recherche."}
            </p>
          ) : (
            <>
              <div className="max-h-96 overflow-y-auto overflow-x-auto rounded-lg border">
                <table className="w-full text-sm">
                  <thead className="sticky top-0 z-10 bg-zinc-100 dark:bg-zinc-800">
                    <tr className="text-left text-xs uppercase tracking-wide text-zinc-600 dark:text-zinc-300">
                      <th scope="col" className="px-3 py-2 font-semibold">Article</th>
                      <th scope="col" className="px-3 py-2 font-semibold">Couleur</th>
                      <th scope="col" className="px-3 py-2 font-semibold">Manche</th>
                      <th scope="col" className="px-3 py-2 font-semibold">Taille</th>
                      <th scope="col" className="px-3 py-2 font-semibold">Code-barres</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y bg-white dark:bg-zinc-900">
                    {affichees.map((l, i) => (
                      <tr key={`${l[0]}|${l[1]}|${l[2]}|${l[3]}|${l[4]}|${i}`} className="hover:bg-amber-50/60 dark:hover:bg-amber-950/20">
                        <td className="whitespace-nowrap px-3 py-1.5 font-medium">{l[0]}</td>
                        <td className="whitespace-nowrap px-3 py-1.5">
                          <span>{couleurLabel(l[1])[0]}</span>
                          <span className="ml-1.5 font-mono text-[10px] text-muted-foreground">{l[1]}</span>
                        </td>
                        <td className="whitespace-nowrap px-3 py-1.5 text-muted-foreground">
                          {l[3] ? (mancheLabel(l[3])?.[0] ?? l[3]) : "—"}
                        </td>
                        <td className="whitespace-nowrap px-3 py-1.5 font-mono">{l[2]}</td>
                        <td className="whitespace-nowrap px-3 py-1.5 font-mono tabular-nums">{l[4]}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              {lignesFiltrees.length > affichees.length && (
                <div className="mt-3 text-center">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setNbAffichees((n) => n + PAS_AFFICHAGE)}
                  >
                    Afficher {Math.min(PAS_AFFICHAGE, lignesFiltrees.length - affichees.length).toLocaleString("fr-FR")} référence(s) de plus
                    ({affichees.length.toLocaleString("fr-FR")} / {lignesFiltrees.length.toLocaleString("fr-FR")})
                  </Button>
                </div>
              )}
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
