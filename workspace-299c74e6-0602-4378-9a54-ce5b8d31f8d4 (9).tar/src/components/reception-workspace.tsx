"use client";

/**
 * Espace de travail « Réception » — réservé aux garçons du stock (rôle
 * « stock ») et au service achats. Séparé du colisage :
 *
 *  1. Le stock prépare (ou choisit) la RÉCEPTION prévue — « Nouvelle » ;
 *  2. Il scanne TOUS les articles reçus à la douchette (zone de scan
 *     ou fichier importé) ;
 *  3. Il pointe le lot sur la réception → attendu / reçu / écart ;
 *  4. Il exporte la LISTE DES CODES (fichier .txt, un code par ligne,
 *     quantités « ×N » conservées) et la ramène au bureau : le service
 *     achats la colle dans l'onglet Colisage pour sortir le colisage.
 *
 * Aucune génération de colisage ici : c'est l'onglet Colisage (achats).
 */

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  AlertTriangle,
  Boxes,
  CalendarRange,
  CheckCircle2,
  ClipboardList,
  Copy,
  FileDown,
  FileUp,
  Loader2,
  Lock,
  LockOpen,
  PackageCheck,
  Plus,
  ScanLine,
  Trash2,
  Truck,
} from "lucide-react";

import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { useToast } from "@/hooks/use-toast";
import {
  developperEntrees,
  extraireEntrees,
  horodatageFichier,
  MAX_CODES_COLISAGE,
  totalPieces,
  TAILLE_MAX_TEXTE_COLISAGE,
  type EntreeScan,
} from "@/lib/colisage";
import { formaterSamedi, type ExportListe } from "@/lib/exports";
import type {
  EtatReception,
  ResumeReception,
} from "@/lib/receptions";

/**
 * Bornes de la semaine dernière (lundi → dimanche) en Europe/Paris —
 * proposition par défaut de la création de réception (le façonnier imprime
 * la semaine N, les pièces arrivent la semaine N+1).
 */
function semainePassee(): { du: string; au: string } {
  const fmt = new Intl.DateTimeFormat("fr-CA", {
    timeZone: "Europe/Paris",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  });
  const p = Object.fromEntries(
    fmt.formatToParts(new Date()).map((x) => [x.type, x.value])
  );
  const aujourdhui = new Date(`${p.year}-${p.month}-${p.day}T12:00:00Z`);
  const joursDepuisLundi = (aujourdhui.getUTCDay() + 6) % 7;
  const lundi = new Date(aujourdhui);
  lundi.setUTCDate(lundi.getUTCDate() - joursDepuisLundi - 7);
  const dimanche = new Date(lundi);
  dimanche.setUTCDate(dimanche.getUTCDate() + 6);
  return { du: lundi.toISOString().slice(0, 10), au: dimanche.toISOString().slice(0, 10) };
}

/**
 * Bornes de la semaine courante (lundi → dimanche) en Europe/Paris —
 * bouton rapide du dialogue de création (utile quand les étiquettes viennent
 * d'être générées cette semaine, donc absentes de la semaine dernière).
 */
function semaineCourante(): { du: string; au: string } {
  const fmt = new Intl.DateTimeFormat("fr-CA", {
    timeZone: "Europe/Paris",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  });
  const p = Object.fromEntries(
    fmt.formatToParts(new Date()).map((x) => [x.type, x.value])
  );
  const aujourdhui = new Date(`${p.year}-${p.month}-${p.day}T12:00:00Z`);
  const joursDepuisLundi = (aujourdhui.getUTCDay() + 6) % 7;
  const lundi = new Date(aujourdhui);
  lundi.setUTCDate(lundi.getUTCDate() - joursDepuisLundi);
  const dimanche = new Date(lundi);
  dimanche.setUTCDate(dimanche.getUTCDate() + 6);
  return { du: lundi.toISOString().slice(0, 10), au: dimanche.toISOString().slice(0, 10) };
}

/** Reconstruit les lignes « code » / « code×N » exportables (fichier douchette). */
function lignesExport(entrees: EntreeScan[]): string {
  return entrees
    .map((e) => (e.quantite > 1 ? `${e.code}×${e.quantite}` : e.code))
    .join("\n");
}

export function ReceptionWorkspace() {
  const { toast } = useToast();

  // ------------------------- Zone de scan (douchette) -------------------------
  const [texteBrut, setTexteBrut] = useState("");
  const [depotActif, setDepotActif] = useState(false);
  const [listeCopiee, setListeCopiee] = useState(false);

  // ------------------------------ Réception --------------------------------
  const [receptions, setReceptions] = useState<ResumeReception[]>([]);
  const [receptionsChargees, setReceptionsChargees] = useState(false);
  const [receptionId, setReceptionId] = useState<string>("");
  const [etat, setEtat] = useState<EtatReception | null>(null);
  const [etatEnCours, setEtatEnCours] = useState(false);
  const [pointageEnCours, setPointageEnCours] = useState(false);
  const [dialogueCreation, setDialogueCreation] = useState(false);
  const [creationEnCours, setCreationEnCours] = useState(false);
  const [nouveauTitre, setNouveauTitre] = useState("");
  const [modeSource, setModeSource] = useState<
    "export" | "periode" | "of" | "tout"
  >("export");
  // Choix « Depuis un export » : la réception prévue existe déjà (préparée
  // par le façonnier dans l'onglet Exports) — on la sélectionne pour scanner.
  const [exportsDispo, setExportsDispo] = useState<ExportListe[]>([]);
  const [exportsEnChargement, setExportsEnChargement] = useState(false);
  const [exportChoisi, setExportChoisi] = useState("");
  const [ofsCreation, setOfsCreation] = useState("");
  const bornesDefaut = useRef(semainePassee());
  const [duCreation, setDuCreation] = useState(bornesDefaut.current.du);
  const [auCreation, setAuCreation] = useState(bornesDefaut.current.au);
  // Aperçu en direct de la source (compteur d'étiquettes AVANT création) —
  // évite le message d'erreur « aucune étiquette » découvert après coup.
  const [apercuSource, setApercuSource] = useState<{
    etiquettes: number;
    lignes: number;
    attendu: number;
  } | null>(null);
  const [apercuEnCours, setApercuEnCours] = useState(false);
  const [erreurCreation, setErreurCreation] = useState<string | null>(null);
  const [confirmationSuppression, setConfirmationSuppression] = useState(false);
  const [actionEnCours, setActionEnCours] = useState(false);

  const receptionSelectionnee = receptions.find((r) => r.id === receptionId);
  const cloturee = etat?.reception.statut === "cloturee";

  /** Export sélectionné dans le dialogue (mode « Depuis un export »). */
  const exportSelectionne = useMemo(
    () => exportsDispo.find((e) => e.id === exportChoisi) ?? null,
    [exportsDispo, exportChoisi]
  );

  const fichierRef = useRef<HTMLInputElement>(null);
  const compteurDepot = useRef(0);

  /** Entrées scannées (code + quantité « ×N ») et pièces détectées. */
  const entrees = useMemo(() => extraireEntrees(texteBrut), [texteBrut]);
  const piecesDetectees = useMemo(() => totalPieces(entrees), [entrees]);
  const nbLignes = entrees.length;

  // -------------------------------------------------------------------------
  // Import fichier : extraction des codes 13 chiffres (liste douchette,
  // export multi-colonnes, présence ou non d'en-tête) + glisser-déposer.
  // -------------------------------------------------------------------------
  async function importerFichier(fichier: File) {
    if (fichier.size > TAILLE_MAX_TEXTE_COLISAGE) {
      toast({
        title: "Fichier trop volumineux",
        description: `Taille maximale : ${Math.round(TAILLE_MAX_TEXTE_COLISAGE / 1_000_000)} Mo.`,
        variant: "destructive",
      });
      return;
    }
    const estTexte =
      /\.txt$|\.csv$|\.text$/i.test(fichier.name) || fichier.type.startsWith("text/");
    if (!estTexte) {
      toast({
        title: "Format non pris en charge",
        description: "Importez un fichier .txt ou .csv contenant les codes-barres.",
        variant: "destructive",
      });
      return;
    }
    try {
      const contenu = await fichier.text();
      const entreesFichier = extraireEntrees(contenu);
      if (entreesFichier.length === 0) {
        toast({
          title: "Aucun code-barres trouvé",
          description: `Aucun code à 13 chiffres détecté dans « ${fichier.name} ».`,
          variant: "destructive",
        });
        return;
      }
      setTexteBrut((precedent) => {
        const base = precedent.trim();
        const ajoute = lignesExport(entreesFichier);
        return base ? `${base}\n${ajoute}` : ajoute;
      });
      toast({
        title: `${totalPieces(entreesFichier).toLocaleString("fr-FR")} pièce(s) importée(s)`,
        description: `Depuis « ${fichier.name} » — ${entreesFichier.length.toLocaleString("fr-FR")} ligne(s), quantités « ×N » conservées.`,
      });
    } catch {
      toast({
        title: "Lecture impossible",
        description: "Le fichier n'a pas pu être lu.",
        variant: "destructive",
      });
    }
  }

  // -------------------------------------------------------------------------
  // Export de la liste des codes scannés (le fichier à ramener au bureau :
  // le service achats le colle dans l'onglet Colisage tel quel).
  // -------------------------------------------------------------------------
  function exporterListeTxt() {
    if (entrees.length === 0) return;
    const blob = new Blob([`${lignesExport(entrees)}\n`], {
      type: "text/plain;charset=utf-8",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `codes_scannes_${horodatageFichier()}.txt`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
    toast({
      title: "Liste des codes exportée (TXT)",
      description: `${piecesDetectees.toLocaleString("fr-FR")} pièce(s) — codes_scannes_${horodatageFichier()}.txt. Ramenez ce fichier au bureau pour le colisage.`,
    });
  }

  async function copierListe() {
    if (entrees.length === 0) return;
    try {
      await navigator.clipboard.writeText(lignesExport(entrees));
      setListeCopiee(true);
      window.setTimeout(() => setListeCopiee(false), 1600);
      toast({
        title: "Liste copiée",
        description: "Collez-la dans l'onglet Colisage ou dans un fichier texte.",
      });
    } catch {
      toast({
        title: "Copie impossible",
        description: "Le navigateur a refusé l'accès au presse-papiers.",
        variant: "destructive",
      });
    }
  }

  // -------------------------------------------------------------------------
  // Réception : chargement, pointage des scans, création, clôture.
  // -------------------------------------------------------------------------
  const chargerReceptions = useCallback(async () => {
    try {
      const reponse = await fetch("/api/receptions", { cache: "no-store" });
      const corps = await reponse.json().catch(() => null);
      if (reponse.ok && corps && Array.isArray(corps.receptions)) {
        setReceptions(corps.receptions as ResumeReception[]);
      }
    } catch {
      // Silencieux : la liste se rechargera au prochain passage.
    } finally {
      setReceptionsChargees(true);
    }
  }, []);

  const chargerEtat = useCallback(async (id: string) => {
    if (!id) {
      setEtat(null);
      return;
    }
    setEtatEnCours(true);
    try {
      const reponse = await fetch(`/api/receptions/${id}`, { cache: "no-store" });
      const corps = await reponse.json().catch(() => null);
      if (reponse.ok && corps && corps.reception) {
        setEtat(corps as EtatReception);
      } else {
        setEtat(null);
        setReceptionId("");
      }
    } catch {
      setEtat(null);
    } finally {
      setEtatEnCours(false);
    }
  }, []);

  useEffect(() => {
    void chargerReceptions();
  }, [chargerReceptions]);

  useEffect(() => {
    void chargerEtat(receptionId);
  }, [receptionId, chargerEtat]);

  // Liste des exports pour le mode « Depuis un export » : rechargée à chaque
  // ouverture du dialogue (un export créé entre-temps doit apparaître).
  useEffect(() => {
    if (!dialogueCreation || modeSource !== "export") return;
    let annule = false;
    setExportsEnChargement(true);
    (async () => {
      try {
        const reponse = await fetch("/api/exports", { cache: "no-store" });
        const corps = await reponse.json().catch(() => null);
        if (
          !annule &&
          reponse.ok &&
          corps &&
          Array.isArray(corps.exports)
        ) {
          setExportsDispo(corps.exports as ExportListe[]);
        }
      } catch {
        // Silencieux : le sélecteur affichera la liste (potentiellement vide)
        // déjà connue — l'utilisateur peut passer en « Par N° d'OF ».
      } finally {
        if (!annule) setExportsEnChargement(false);
      }
    })();
    return () => {
      annule = true;
    };
  }, [dialogueCreation, modeSource]);

  // Sélection d'export remise à zéro à chaque ouverture du dialogue.
  useEffect(() => {
    if (dialogueCreation) setExportChoisi("");
  }, [dialogueCreation]);

  // Aperçu en direct de la source choisie dans le dialogue de création :
  // compte les étiquettes correspondantes (sans rien écrire) pour que le
  // compteur « X étiquette(s) → Y ligne(s) » s'affiche AVANT de cliquer.
  // (Mode « Depuis un export » : le résumé vient de l'export lui-même —
  // pas d'aperçu serveur nécessaire.)
  useEffect(() => {
    if (!dialogueCreation || modeSource === "export") return;
    const source =
      modeSource === "of"
        ? {
            mode: "of" as const,
            ofs: ofsCreation
              .split(/[\s,;]+/)
              .map((o) => o.trim())
              .filter(Boolean),
          }
        : modeSource === "periode"
          ? { mode: "periode" as const, du: duCreation, au: auCreation }
          : { mode: "tout" as const };
    setApercuEnCours(true);
    setErreurCreation(null);
    const minuteur = setTimeout(async () => {
      try {
        const reponse = await fetch("/api/receptions/preview", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ source }),
        });
        const corps = await reponse.json().catch(() => null);
        if (!reponse.ok) {
          setApercuSource(null);
          setErreurCreation(
            (corps && typeof corps.error === "string" && corps.error) ||
              "Aperçu impossible."
          );
        } else {
          setApercuSource(corps as { etiquettes: number; lignes: number; attendu: number });
        }
      } catch {
        setApercuSource(null);
        setErreurCreation("Connexion au serveur impossible.");
      } finally {
        setApercuEnCours(false);
      }
    }, 400);
    return () => clearTimeout(minuteur);
  }, [dialogueCreation, modeSource, duCreation, auCreation, ofsCreation]);

  async function pointerScans() {
    if (!receptionId || entrees.length === 0) return;
    // Les quantités « ×N » sont développées en occurrences : le contrat de
    // l'API reste « une occurrence = une pièce ».
    const codes = developperEntrees(entrees);
    if (codes.length > MAX_CODES_COLISAGE) {
      toast({
        title: "Trop de pièces dans le lot",
        description: `${codes.length.toLocaleString("fr-FR")} pièce(s) — maximum ${MAX_CODES_COLISAGE.toLocaleString("fr-FR")}. Réduisez les quantités « ×N » ou pointez en plusieurs fois.`,
        variant: "destructive",
      });
      return;
    }
    setPointageEnCours(true);
    try {
      const reponse = await fetch(`/api/receptions/${receptionId}/pointer`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ codes }),
      });
      const corps = await reponse.json().catch(() => null);
      if (!reponse.ok) {
        const message =
          (corps && typeof corps.error === "string" && corps.error) ||
          "Pointage impossible.";
        toast({ title: "Pointage impossible", description: message, variant: "destructive" });
        return;
      }
      setEtat(corps as EtatReception);
      const resume = (corps as EtatReception).resume;
      toast({
        title: `${codes.length.toLocaleString("fr-FR")} pièce(s) pointée(s) sur la réception`,
        description: `Reçu ${resume.recuTotal.toLocaleString("fr-FR")} / ${resume.attenduTotal.toLocaleString("fr-FR")} attendu(s) — ${resume.tauxPct} %.`,
      });
      void chargerReceptions();
    } catch {
      toast({
        title: "Erreur réseau",
        description: "Connexion au serveur impossible. Réessayez.",
        variant: "destructive",
      });
    } finally {
      setPointageEnCours(false);
    }
  }

  async function creerReception() {
    // Mode « Depuis un export » : la réception prévue existe déjà (l'export
    // est enregistré comme réception) — on la sélectionne pour le scan,
    // sans rien dupliquer.
    if (modeSource === "export") {
      if (!exportSelectionne) {
        toast({
          title: "Choisissez un export",
          description: "Sélectionnez l'export reçu dans la liste, ou passez en « Par N° d'OF ».",
          variant: "destructive",
        });
        return;
      }
      setDialogueCreation(false);
      setReceptionId(exportSelectionne.id);
      toast({
        title: "Réception prête",
        description: `« ${exportSelectionne.titre} » — ${exportSelectionne.lignes.length} ligne(s) attendue(s), ${exportSelectionne.quantiteTotale} pièce(s). Scannez les articles reçus ci-dessous.`,
      });
      return;
    }
    const titre = nouveauTitre.trim();
    if (titre.length === 0) {
      toast({
        title: "Titre requis",
        description: "Donnez un nom à la réception (ex. « Réception semaine 38 »).",
        variant: "destructive",
      });
      return;
    }
    setCreationEnCours(true);
    try {
      const source =
        modeSource === "of"
          ? {
              mode: "of" as const,
              ofs: ofsCreation
                .split(/[\s,;]+/)
                .map((o) => o.trim())
                .filter(Boolean),
            }
          : modeSource === "periode"
            ? { mode: "periode" as const, du: duCreation, au: auCreation }
            : { mode: "tout" as const };
      const reponse = await fetch("/api/receptions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ titre, source }),
      });
      const corps = await reponse.json().catch(() => null);
      if (!reponse.ok) {
        const message =
          (corps && typeof corps.error === "string" && corps.error) ||
          "Création impossible.";
        setErreurCreation(message); // visible dans le dialogue (en plus du toast)
        toast({ title: "Création impossible", description: message, variant: "destructive" });
        return;
      }
      setDialogueCreation(false);
      setNouveauTitre("");
      setErreurCreation(null);
      await chargerReceptions();
      if (corps && typeof corps.id === "string") setReceptionId(corps.id);
      toast({
        title: "Réception créée",
        description: `« ${titre} » — ${corps?.lignes ?? 0} ligne(s) attendue(s) depuis les étiquettes générées.`,
      });
    } catch {
      toast({
        title: "Erreur réseau",
        description: "Connexion au serveur impossible. Réessayez.",
        variant: "destructive",
      });
    } finally {
      setCreationEnCours(false);
    }
  }

  async function basculerCloture() {
    if (!receptionId || !etat) return;
    setActionEnCours(true);
    try {
      const nouveauStatut = cloturee ? "ouverte" : "cloturee";
      const reponse = await fetch(`/api/receptions/${receptionId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ statut: nouveauStatut }),
      });
      if (!reponse.ok) {
        const corps = await reponse.json().catch(() => null);
        toast({
          title: "Action impossible",
          description: (corps && typeof corps.error === "string" && corps.error) || "Réessayez.",
          variant: "destructive",
        });
        return;
      }
      toast({
        title: nouveauStatut === "cloturee" ? "Réception clôturée" : "Réception rouverte",
        description:
          nouveauStatut === "cloturee"
            ? "Le pointage est verrouillé — état figé pour l'export."
            : "Le pointage est de nouveau possible.",
      });
      await chargerEtat(receptionId);
      void chargerReceptions();
    } finally {
      setActionEnCours(false);
    }
  }

  async function supprimerReception() {
    if (!receptionId) return;
    setActionEnCours(true);
    try {
      const reponse = await fetch(`/api/receptions/${receptionId}`, { method: "DELETE" });
      if (!reponse.ok) {
        const corps = await reponse.json().catch(() => null);
        toast({
          title: "Suppression impossible",
          description: (corps && typeof corps.error === "string" && corps.error) || "Réessayez.",
          variant: "destructive",
        });
        return;
      }
      toast({ title: "Réception supprimée", description: "Les étiquettes générées restent en base." });
      setReceptionId("");
      setEtat(null);
      await chargerReceptions();
    } finally {
      setActionEnCours(false);
      setConfirmationSuppression(false);
    }
  }

  return (
    <div className="space-y-6" aria-label="Réception des articles">
      {/* ------------------------ Réception prévue ------------------------ */}
      <Card className="card-lift" aria-label="Réception prévue">
        <CardHeader className="pb-4">
          <CardTitle className="flex flex-wrap items-center justify-between gap-2 text-base">
            <span className="flex items-center gap-2">
              <ClipboardList className="h-4 w-4 text-amber-600" aria-hidden="true" />
              Réception prévue
              {etat && (
                <Badge
                  variant="outline"
                  className={
                    cloturee
                      ? "border-zinc-400 text-zinc-500"
                      : "border-green-600/60 text-green-700 dark:text-green-400"
                  }
                >
                  {cloturee ? "clôturée" : "ouverte"}
                </Badge>
              )}
            </span>
            <span className="flex items-center gap-1.5">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setDialogueCreation(true)}
                className="h-8 px-2 text-xs"
              >
                <Plus className="mr-1 h-3.5 w-3.5" aria-hidden="true" />
                Nouvelle
              </Button>
              {etat && (
                <>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={basculerCloture}
                    disabled={actionEnCours}
                    className="h-8 px-2 text-xs text-zinc-500 hover:text-amber-700"
                  >
                    {actionEnCours ? (
                      <Loader2 className="mr-1 h-3.5 w-3.5 animate-spin" aria-hidden="true" />
                    ) : cloturee ? (
                      <LockOpen className="mr-1 h-3.5 w-3.5" aria-hidden="true" />
                    ) : (
                      <Lock className="mr-1 h-3.5 w-3.5" aria-hidden="true" />
                    )}
                    {cloturee ? "Rouvrir" : "Clôturer"}
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setConfirmationSuppression(true)}
                    disabled={actionEnCours}
                    className="h-8 px-2 text-xs text-zinc-500 hover:text-red-600"
                  >
                    <Trash2 className="mr-1 h-3.5 w-3.5" aria-hidden="true" />
                    Supprimer
                  </Button>
                </>
              )}
            </span>
          </CardTitle>
          <CardDescription>
            Choisissez la réception correspondant au lot reçu, pointez les scans
            pour comparer <strong>attendu / reçu / écart</strong>, puis exportez
            la liste des codes ci-dessous pour le colisage.
          </CardDescription>
        </CardHeader>

        <CardContent className="space-y-4">
          {/* Sélecteur de réception */}
          <div className="flex flex-wrap items-center gap-2">
            <Select
              value={receptionId || undefined}
              onValueChange={(v) => setReceptionId(v)}
            >
              <SelectTrigger
                className="h-10 w-full sm:w-[26rem]"
                aria-label="Sélectionner la réception prévue"
              >
                <SelectValue
                  placeholder={
                    receptionsChargees && receptions.length === 0
                      ? "Aucune réception — créez-en une"
                      : "Choisir une réception…"
                  }
                />
              </SelectTrigger>
              <SelectContent>
                {receptions.map((r) => (
                  <SelectItem key={r.id} value={r.id}>
                    <span className="flex items-baseline gap-2">
                      <span className="font-medium">{r.titre}</span>
                      <span className="text-xs tabular-nums text-muted-foreground">
                        {r.recuTotal.toLocaleString("fr-FR")} /{" "}
                        {r.attenduTotal.toLocaleString("fr-FR")} p. · {r.tauxPct} %
                        {r.statut === "cloturee" ? " · clôturée" : ""}
                      </span>
                    </span>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {etatEnCours && (
              <Loader2 className="h-4 w-4 animate-spin text-amber-600" aria-hidden="true" />
            )}
          </div>

          {/* État de la réception sélectionnée */}
          {etat && (
            <>
              {/* Résumé + progression */}
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                {[
                  {
                    icone: ClipboardList,
                    valeur: etat.resume.attenduTotal,
                    libelle: "Attendu",
                  },
                  {
                    icone: PackageCheck,
                    valeur: etat.resume.recuTotal,
                    libelle: "Reçu (prévu)",
                  },
                  {
                    icone: AlertTriangle,
                    valeur: Math.max(0, etat.resume.attenduTotal - etat.resume.recuTotal),
                    libelle: "Manquant",
                  },
                  {
                    icone: Boxes,
                    valeur: etat.resume.horsPrevueQuantite + etat.resume.inconnusQuantite,
                    libelle: "Hors prévu / inconnu",
                  },
                ].map(({ icone: Icone, valeur, libelle }) => (
                  <div
                    key={libelle}
                    className="rounded-lg border bg-white p-3 text-center dark:bg-zinc-900"
                  >
                    <dd className="flex items-center justify-center gap-1.5 font-serif text-xl font-semibold tabular-nums">
                      <Icone className="h-4 w-4 text-amber-600" aria-hidden="true" />
                      {valeur.toLocaleString("fr-FR")}
                    </dd>
                    <dt className="mt-0.5 text-[11px] uppercase tracking-wide text-muted-foreground">
                      {libelle}
                    </dt>
                  </div>
                ))}
              </div>

              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span>
                    {etat.resume.lignesCompletes}/{etat.resume.lignesTotal} ligne(s)
                    complète(s) — {etat.resume.lignesPartielles} partielle(s),{" "}
                    {etat.resume.lignesZero} à zéro
                  </span>
                  <span className="font-semibold tabular-nums text-amber-700 dark:text-amber-400">
                    {etat.resume.tauxPct} %
                  </span>
                </div>
                <Progress
                  value={etat.resume.tauxPct}
                  aria-label={`Réception à ${etat.resume.tauxPct} %`}
                />
              </div>

              {/* Pointage du lot scanné */}
              <div className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-dashed p-3">
                <p className="text-xs text-muted-foreground">
                  {entrees.length > 0
                    ? `${piecesDetectees.toLocaleString("fr-FR")} pièce(s) dans la zone de scan ci-dessus.`
                    : "Scannez ou collez d'abord les articles reçus dans la zone de scan."}
                </p>
                <Button
                  onClick={pointerScans}
                  disabled={
                    pointageEnCours || entrees.length === 0 || cloturee
                  }
                  className="h-10 bg-green-700 font-semibold text-white hover:bg-green-800"
                >
                  {pointageEnCours ? (
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" aria-hidden="true" />
                  ) : (
                    <PackageCheck className="mr-2 h-4 w-4" aria-hidden="true" />
                  )}
                  {cloturee
                    ? "Réception clôturée"
                    : `Pointer les ${piecesDetectees.toLocaleString("fr-FR")} pièce(s)`}
                </Button>
              </div>

              {/* Tableau attendu / reçu / écart */}
              <div className="overflow-hidden rounded-lg border">
                <div className="max-h-72 overflow-y-auto">
                  <table className="w-full text-sm">
                    <caption className="sr-only">
                      État de la réception : attendu, reçu et écart par ligne
                    </caption>
                    <thead className="sticky top-0 z-10 bg-white shadow-[0_1px_0_0] shadow-zinc-200 dark:bg-zinc-900 dark:shadow-zinc-700">
                      <tr>
                        <th scope="col" className="px-3 py-2 text-left font-semibold">OF</th>
                        <th scope="col" className="px-3 py-2 text-left font-semibold">Modèle</th>
                        <th scope="col" className="px-3 py-2 text-left font-semibold">Couleur</th>
                        <th scope="col" className="px-3 py-2 text-left font-semibold">Taille</th>
                        <th scope="col" className="px-3 py-2 text-right font-semibold">Attendu</th>
                        <th scope="col" className="px-3 py-2 text-right font-semibold">Reçu</th>
                        <th scope="col" className="px-3 py-2 text-right font-semibold">Écart</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y">
                      {etat.lignes.map((l) => (
                        <tr
                          key={l.id}
                          className="transition-colors hover:bg-amber-50/60 dark:hover:bg-amber-950/20"
                        >
                          <td className="whitespace-nowrap px-3 py-1.5 font-mono text-xs">
                            {l.of || <span className="text-muted-foreground">—</span>}
                          </td>
                          <td className="px-3 py-1.5 font-medium">{l.modele}</td>
                          <td className="px-3 py-1.5">
                            {l.couleur}
                            {l.couleurCode && (
                              <span className="ml-1.5 font-mono text-[10px] text-muted-foreground">
                                {l.couleurCode}
                              </span>
                            )}
                          </td>
                          <td className="px-3 py-1.5 font-mono text-xs">{l.taille}</td>
                          <td className="px-3 py-1.5 text-right tabular-nums">
                            {l.attendu}
                          </td>
                          <td className="px-3 py-1.5 text-right font-bold tabular-nums">
                            {l.recu}
                          </td>
                          <td className="px-3 py-1.5 text-right">
                            <Badge
                              variant="outline"
                              className={
                                l.statut === "complet"
                                  ? "border-green-600/50 text-green-700 dark:text-green-400"
                                  : l.statut === "excedent"
                                    ? "border-red-500/50 text-red-700 dark:text-red-400"
                                    : l.statut === "partiel"
                                      ? "border-amber-600/50 text-amber-700 dark:text-amber-400"
                                      : "border-zinc-400/60 text-zinc-500"
                              }
                            >
                              {l.ecart > 0 ? `+${l.ecart}` : l.ecart}
                            </Badge>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Codes hors prévue / inconnus pointés */}
              {(etat.horsPrevue.length > 0 || etat.inconnus.length > 0) && (
                <div
                  className="rounded-lg border border-amber-300 bg-amber-50 p-3 dark:border-amber-500/40 dark:bg-amber-950/20"
                  role="note"
                >
                  <p className="flex items-center gap-2 text-sm font-semibold text-amber-800 dark:text-amber-300">
                    <AlertTriangle className="h-4 w-4 shrink-0" aria-hidden="true" />
                    {etat.resume.horsPrevueQuantite} pièce(s) hors prévue ·{" "}
                    {etat.resume.inconnusQuantite} inconnue(s) — pointées mais
                    sans ligne attendue
                  </p>
                  <div className="mt-2 max-h-24 overflow-y-auto rounded border border-amber-200 bg-white p-2 font-mono text-xs leading-relaxed text-amber-900 dark:border-amber-500/30 dark:bg-zinc-950 dark:text-amber-200">
                    {etat.horsPrevue.map((h) => (
                      <div key={h.code} className="flex justify-between gap-3">
                        <span>
                          {h.code}
                          <span className="ml-2 font-sans text-[11px] text-muted-foreground">
                            {h.modele}
                          </span>
                        </span>
                        <span className="tabular-nums">× {h.quantite}</span>
                      </div>
                    ))}
                    {etat.inconnus.map((i) => (
                      <div key={i.code} className="flex justify-between gap-3">
                        <span>{i.code}</span>
                        <span className="tabular-nums">× {i.quantite}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </>
          )}

          {!etat && !etatEnCours && receptionId === "" && (
            <p className="rounded-lg border border-dashed p-4 text-sm text-muted-foreground">
              {receptions.length === 0
                ? "Aucune réception pour l'instant. Cliquez sur « Nouvelle » pour préparer la réception des pièces imprimées (semaine N → réception N+1) — les lignes attendues sont calculées depuis les étiquettes déjà générées et enregistrées en base."
                : "Sélectionnez une réception dans la liste pour voir l'état attendu / reçu."}
            </p>
          )}
        </CardContent>
      </Card>

      {/* --------------------- Zone de scan (douchette) --------------------- */}
      <Card
        className={`card-lift relative transition-shadow ${
          depotActif ? "ring-2 ring-amber-500/70 ring-offset-2 ring-offset-background dark:ring-offset-zinc-950" : ""
        }`}
        onDragEnter={(e) => {
          e.preventDefault();
          compteurDepot.current += 1;
          setDepotActif(true);
        }}
        onDragOver={(e) => e.preventDefault()}
        onDragLeave={() => {
          compteurDepot.current -= 1;
          if (compteurDepot.current <= 0) {
            compteurDepot.current = 0;
            setDepotActif(false);
          }
        }}
        onDrop={async (e) => {
          e.preventDefault();
          compteurDepot.current = 0;
          setDepotActif(false);
          const fichier = e.dataTransfer.files?.[0];
          if (fichier) await importerFichier(fichier);
        }}
      >
        {depotActif && (
          <div
            className="depot-voile pointer-events-none absolute inset-0 z-20 flex items-center justify-center rounded-xl border-2 border-dashed border-amber-500 bg-amber-50/90 dark:bg-zinc-950/90"
            aria-hidden="true"
          >
            <div className="flex items-center gap-3 text-amber-800 dark:text-amber-300">
              <FileUp className="depot-icone h-8 w-8" />
              <p className="text-lg font-bold">Déposez le fichier de codes ici</p>
            </div>
          </div>
        )}

        <CardHeader className="pb-4">
          <CardTitle className="flex items-center justify-between gap-2 text-base">
            <span className="flex items-center gap-2">
              <ScanLine className="h-4 w-4 text-amber-600" aria-hidden="true" />
              Scan des articles reçus
            </span>
            <Badge variant="secondary" aria-live="polite">
              {piecesDetectees.toLocaleString("fr-FR")} pièce(s) détectée(s)
            </Badge>
          </CardTitle>
          <CardDescription>
            Scannez à la douchette <strong>tous les articles reçus</strong> (les
            codes s&apos;ajoutent un par ligne, 3 000 à 4 000 lignes acceptées),
            ou collez / importez une liste. Ensuite : pointez le lot sur la
            réception choisie ci-dessus, puis exportez la liste des codes pour
            l&apos;atelier colisage.
          </CardDescription>
        </CardHeader>

        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="codes-reception">Codes-barres scannés</Label>
            <Textarea
              id="codes-reception"
              value={texteBrut}
              onChange={(e) => setTexteBrut(e.target.value)}
              placeholder={"3700791700130\n3700791700147×12\n3700791700154\n…"}
              className="min-h-44 resize-y font-mono text-sm leading-relaxed"
              spellCheck={false}
              autoComplete="off"
            />
            <p className="flex items-start gap-1.5 text-xs text-muted-foreground">
              <Truck className="mt-0.5 h-3.5 w-3.5 shrink-0" aria-hidden="true" />
              <span>
                {nbLignes.toLocaleString("fr-FR")} ligne(s) scannée(s) —{" "}
                {piecesDetectees.toLocaleString("fr-FR")} pièce(s) au total.
                <span className="mt-1 block">
                  <strong className="font-semibold text-amber-700 dark:text-amber-400">
                    Beaucoup de pièces identiques&nbsp;?
                  </strong>{" "}
                  ajoutez{" "}
                  <code className="rounded bg-zinc-100 px-1 font-mono text-[11px] dark:bg-zinc-800">
                    ×N
                  </code>{" "}
                  après un code — ex.{" "}
                  <code className="rounded bg-zinc-100 px-1 font-mono text-[11px] dark:bg-zinc-800">
                    3700791700147×12
                  </code>{" "}
                  = 12 pièces sans les scanner une à une.
                </span>
              </span>
            </p>
          </div>

          <input
            ref={fichierRef}
            type="file"
            accept=".txt,.csv,text/plain,text/csv"
            className="hidden"
            onChange={async (e) => {
              const fichier = e.target.files?.[0];
              if (fichier) await importerFichier(fichier);
              e.target.value = "";
            }}
            aria-hidden="true"
            tabIndex={-1}
          />

          <div className="grid gap-2 sm:grid-cols-3">
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="outline"
                  onClick={() => fichierRef.current?.click()}
                  className="h-10 w-full"
                >
                  <FileUp className="mr-2 h-4 w-4" aria-hidden="true" />
                  Importer un fichier
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>.txt / .csv — codes 13 chiffres extraits automatiquement, ou glissez le fichier sur la carte</p>
              </TooltipContent>
            </Tooltip>
            <Button
              variant="outline"
              onClick={() => void copierListe()}
              disabled={entrees.length === 0}
              className="h-10 w-full"
            >
              {listeCopiee ? (
                <CheckCircle2 className="mr-2 h-4 w-4 text-green-600" aria-hidden="true" />
              ) : (
                <Copy className="mr-2 h-4 w-4" aria-hidden="true" />
              )}
              {listeCopiee ? "Copiée" : "Copier la liste"}
            </Button>
            <Button
              variant="ghost"
              onClick={() => setTexteBrut("")}
              disabled={!texteBrut}
              className="h-10 w-full"
            >
              <Trash2 className="mr-2 h-4 w-4" aria-hidden="true" />
              Vider la zone
            </Button>
          </div>
        </CardContent>

        <CardFooter className="flex flex-wrap items-center justify-between gap-2 border-t bg-zinc-50/60 p-4 dark:bg-zinc-900/60">
          <p className="text-xs text-muted-foreground">
            Le fichier exporté s&apos;appelle{" "}
            <code className="rounded bg-zinc-100 px-1 font-mono text-[11px] dark:bg-zinc-800">
              codes_scannes_AAAAMMJJ_HHmm.txt
            </code>{" "}
            — à coller tel quel dans l&apos;onglet Colisage (service achats).
          </p>
          <Button
            onClick={exporterListeTxt}
            disabled={entrees.length === 0}
            className="h-10 bg-amber-600 font-semibold text-white hover:bg-amber-700"
          >
            <FileDown className="mr-2 h-4 w-4" aria-hidden="true" />
            Exporter la liste des codes (TXT)
          </Button>
        </CardFooter>
      </Card>

      {/* ------------------- Dialogue : nouvelle réception ------------------- */}
      <Dialog open={dialogueCreation} onOpenChange={setDialogueCreation}>
        <DialogContent className="sm:max-w-md" aria-label="Créer une réception prévue">
          <DialogHeader>
            <DialogTitle>Nouvelle réception prévue</DialogTitle>
            <DialogDescription>
              Choisissez la source : un <strong>export</strong> déjà préparé
              par le façonnier, ou les étiquettes générées (copies comprises),
              regroupées par OF → modèle → couleur → taille.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            {modeSource !== "export" && (
              <div className="space-y-2">
                <Label htmlFor="titre-reception">Titre de la réception</Label>
                <Input
                  id="titre-reception"
                  value={nouveauTitre}
                  onChange={(e) => setNouveauTitre(e.target.value)}
                  placeholder="ex. Réception semaine 38 — façonnier"
                  maxLength={120}
                  autoComplete="off"
                />
              </div>
            )}

            <RadioGroup
              value={modeSource}
              onValueChange={(v) =>
                setModeSource(v as "export" | "periode" | "of" | "tout")
              }
              className="flex flex-wrap gap-x-4 gap-y-2"
              aria-label="Source des lignes attendues"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="export" id="src-export" />
                <Label htmlFor="src-export" className="cursor-pointer font-normal">
                  Depuis un export
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="of" id="src-of" />
                <Label htmlFor="src-of" className="cursor-pointer font-normal">
                  Par N° d&apos;OF
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="periode" id="src-periode" />
                <Label htmlFor="src-periode" className="cursor-pointer font-normal">
                  Par période
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="tout" id="src-tout" />
                <Label htmlFor="src-tout" className="cursor-pointer font-normal">
                  Tout le journal
                </Label>
              </div>
            </RadioGroup>

            {modeSource === "export" ? (
              <div className="space-y-2">
                <Label htmlFor="export-reception">
                  Export du façonnier à réceptionner
                </Label>
                {exportsEnChargement ? (
                  <p
                    className="flex items-center gap-2 rounded-md border bg-muted/40 px-3 py-2 text-xs text-muted-foreground"
                    aria-live="polite"
                  >
                    <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden="true" />
                    Chargement des exports…
                  </p>
                ) : exportsDispo.length === 0 ? (
                  <p className="rounded-md border border-dashed p-3 text-xs text-muted-foreground">
                    Aucun export préparé pour l&apos;instant — choisissez « Par
                    N° d&apos;OF » pour créer la réception depuis les numéros
                    d&apos;OF du lot reçu.
                  </p>
                ) : (
                  <Select
                    value={exportChoisi || undefined}
                    onValueChange={setExportChoisi}
                  >
                    <SelectTrigger
                      id="export-reception"
                      className="h-10"
                      aria-label="Choisir l'export à réceptionner"
                    >
                      <SelectValue placeholder="Choisir un export…" />
                    </SelectTrigger>
                    <SelectContent>
                      {exportsDispo.map((e) => (
                        <SelectItem key={e.id} value={e.id}>
                          <span className="flex items-baseline gap-2">
                            <span className="font-medium">{e.titre}</span>
                            <span className="text-xs tabular-nums text-muted-foreground">
                              {formaterSamedi(e.dateExport)} · {e.lignes.length} ligne(s)
                              · {e.quantiteTotale} p.
                            </span>
                          </span>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                )}
              </div>
            ) : modeSource === "periode" ? (
              <div className="space-y-2">
                <Label>
                  Étiquettes générées entre deux dates (Europe/Paris)
                </Label>
                <div className="flex items-center gap-2">
                  <CalendarRange
                    className="h-4 w-4 shrink-0 text-amber-600"
                    aria-hidden="true"
                  />
                  <Input
                    type="date"
                    value={duCreation}
                    onChange={(e) => setDuCreation(e.target.value)}
                    aria-label="Date de début (génération des étiquettes)"
                    className="h-10"
                  />
                  <span className="text-muted-foreground">→</span>
                  <Input
                    type="date"
                    value={auCreation}
                    onChange={(e) => setAuCreation(e.target.value)}
                    aria-label="Date de fin (génération des étiquettes)"
                    className="h-10"
                  />
                </div>
                <p className="text-xs text-muted-foreground">
                  Par défaut : la semaine dernière (lundi → dimanche) — le lot
                  imprimé par le façonnier que vous réceptionnez cette semaine.
                </p>
                <div className="flex flex-wrap gap-1.5">
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    className="h-7 px-2 text-xs"
                    onClick={() => {
                      const s = semainePassee();
                      setDuCreation(s.du);
                      setAuCreation(s.au);
                    }}
                  >
                    Semaine dernière
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    className="h-7 px-2 text-xs"
                    onClick={() => {
                      const s = semaineCourante();
                      setDuCreation(s.du);
                      setAuCreation(s.au);
                    }}
                  >
                    Cette semaine
                  </Button>
                </div>
              </div>
            ) : modeSource === "of" ? (
              <div className="space-y-2">
                <Label htmlFor="ofs-reception">Numéros d&apos;OF du lot envoyé</Label>
                <Textarea
                  id="ofs-reception"
                  value={ofsCreation}
                  onChange={(e) => setOfsCreation(e.target.value)}
                  placeholder={"078594\n078910\n078955"}
                  className="min-h-20 resize-y font-mono text-sm"
                  spellCheck={false}
                  autoComplete="off"
                />
                <p className="text-xs text-muted-foreground">
                  Un OF par ligne (ou séparés par des virgules) — 50 maximum.
                </p>
              </div>
            ) : (
              <p className="rounded-lg border border-dashed p-3 text-xs text-muted-foreground">
                Toutes les étiquettes déjà générées et enregistrées en base
                deviennent les lignes attendues de cette réception.
              </p>
            )}
          </div>

          {/* Aperçu : ce que la source va produire, AVANT de confirmer */}
          {modeSource === "export" ? (
            exportSelectionne ? (
              <div
                className="rounded-md border border-green-300 bg-green-50 px-3 py-2 text-xs font-medium text-green-800 dark:border-green-900 dark:bg-green-950/40 dark:text-green-300"
                aria-live="polite"
              >
                ✓ « {exportSelectionne.titre} » — {exportSelectionne.lignes.length} ligne(s)
                attendue(s), {exportSelectionne.quantiteTotale} pièce(s) — sera
                sélectionné pour le scan.
              </div>
            ) : exportsDispo.length > 0 && !exportsEnChargement ? (
              <div className="rounded-md border border-amber-300 bg-amber-50 px-3 py-2 text-xs text-amber-900 dark:border-amber-900 dark:bg-amber-950/40 dark:text-amber-300">
                Sélectionnez dans la liste l&apos;export correspondant au lot
                reçu.
              </div>
            ) : null
          ) : apercuEnCours ? (
            <p className="flex items-center gap-2 rounded-md border bg-muted/40 px-3 py-2 text-xs text-muted-foreground">
              <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden="true" />
              Vérification de la source…
            </p>
          ) : erreurCreation ? (
            <div
              role="alert"
              className="rounded-md border border-red-300 bg-red-50 px-3 py-2 text-xs font-medium text-red-800 dark:border-red-900 dark:bg-red-950/40 dark:text-red-300"
            >
              {erreurCreation}
            </div>
          ) : apercuSource ? (
            apercuSource.etiquettes > 0 ? (
              <div className="rounded-md border border-green-300 bg-green-50 px-3 py-2 text-xs font-medium text-green-800 dark:border-green-900 dark:bg-green-950/40 dark:text-green-300">
                ✓ {apercuSource.etiquettes.toLocaleString("fr-FR")} étiquette(s)
                trouvée(s) → {apercuSource.lignes.toLocaleString("fr-FR")} ligne(s)
                attendue(s), {apercuSource.attendu.toLocaleString("fr-FR")} pièce(s)
              </div>
            ) : (
              <div className="rounded-md border border-amber-300 bg-amber-50 px-3 py-2 text-xs text-amber-900 dark:border-amber-900 dark:bg-amber-950/40 dark:text-amber-300">
                Aucune étiquette générée ne correspond à cette source — choisissez
                « Tout le journal », élargissez la période ou vérifiez les N° d&apos;OF.
              </div>
            )
          ) : null}

          <DialogFooter className="gap-2">
            <Button
              variant="outline"
              onClick={() => setDialogueCreation(false)}
              disabled={creationEnCours}
            >
              Annuler
            </Button>
            <Button
              onClick={creerReception}
              disabled={
                creationEnCours ||
                (modeSource === "export"
                  ? !exportSelectionne
                  : apercuEnCours ||
                    (apercuSource !== null && apercuSource.etiquettes === 0))
              }
              className="bg-amber-600 font-semibold text-white hover:bg-amber-700"
            >
              {creationEnCours ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" aria-hidden="true" />
              ) : (
                <Plus className="mr-2 h-4 w-4" aria-hidden="true" />
              )}
              {modeSource === "export" ? "Utiliser cet export" : "Créer la réception"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ------------------- Confirmation de suppression ------------------- */}
      <AlertDialog
        open={confirmationSuppression}
        onOpenChange={setConfirmationSuppression}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Supprimer cette réception ?</AlertDialogTitle>
            <AlertDialogDescription>
              Les lignes attendues et les pointages de «{" "}
              {etat?.reception.titre ?? "cette réception"} » seront supprimés.
              Les étiquettes générées restent en base : vous pourrez recréer la
              réception depuis les mêmes OF ou la même période.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={actionEnCours}>Annuler</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => {
                e.preventDefault();
                void supprimerReception();
              }}
              className="bg-red-600 font-semibold text-white hover:bg-red-700"
            >
              {actionEnCours ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" aria-hidden="true" />
              ) : (
                <Trash2 className="mr-2 h-4 w-4" aria-hidden="true" />
              )}
              Supprimer
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
