"use client";

/**
 * Garde des comptes — Clément Design, Étiquettes & colisage.
 *
 * Trois responsabilités, entièrement transparentes pour le reste de la page :
 *  1. Fournit le contexte de session (compte connecté) à toute l'application
 *     via le hook `useCompte()` ;
 *  2. Si des comptes existent (cloud.config.json) et que personne n'est
 *     connecté, affiche l'écran de connexion élégant à la place de l'app ;
 *  3. `BadgeCompte` : petite pastille d'en-tête (identité + déconnexion).
 *
 * Si AUCUN compte n'est configuré (installation historique), l'application
 * s'affiche directement : zéro régression.
 */

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";
import {
  Boxes,
  Building2,
  Factory,
  Globe,
  Loader2,
  LogOut,
  LockKeyhole,
  ShieldCheck,
  ShoppingCart,
  Star,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";

// ---------------------------------------------------------------------------
// Types + contexte
// ---------------------------------------------------------------------------

export interface ComptePublic {
  identifiant: string;
  nom: string;
  role: "stock" | "achats" | "faconnier" | "france";
  siteId: string;
  siteLabel: string;
}

// ---------------------------------------------------------------------------
// Droits par rôle — COPIE CLIENT des helpers de src/lib/cloud/session.ts
// (la version serveur importe node:crypto et ne doit JAMAIS être chargée
// dans le navigateur : cette copie pure reste synchronisée manuellement).
// ---------------------------------------------------------------------------

/** Réception des articles : stock, achats (+ ancien rôle 'france'). */
export function peutReception(role: ComptePublic["role"]): boolean {
  return role === "stock" || role === "achats" || role === "france";
}

/** Colisage : achats uniquement (+ ancien rôle 'france') — pas le stock. */
export function peutColisage(role: ComptePublic["role"]): boolean {
  return role === "achats" || role === "france";
}

/** Gestion des comptes (codes d'accès) : achats + ancien rôle 'france'. */
export function peutGererComptes(role: ComptePublic["role"]): boolean {
  return role === "achats" || role === "france";
}

/** Libellé du rôle (écran de connexion, bandeaux, panneau comptes). */
export function libelleRole(role: ComptePublic["role"]): string {
  switch (role) {
    case "stock":
      return "Stock — réception & étiquettes";
    case "achats":
      return "Achats — accès complet";
    case "france":
      return "Accès complet (ancien)";
    default:
      return "Façonnier — étiquettes";
  }
}

interface ReponseAuth {
  authActive: boolean;
  erreurConfig: string | null;
  compte: ComptePublic | null;
  comptes: ComptePublic[];
}

interface CompteContexte {
  charge: boolean;
  authActive: boolean;
  erreurConfig: string | null;
  compte: ComptePublic | null;
  comptes: ComptePublic[];
  rafraichir: () => Promise<void>;
  deconnecter: () => Promise<void>;
}

const Ctx = createContext<CompteContexte | null>(null);

/** Hook d'accès à la session (compte connecté, rôle, site). */
export function useCompte(): CompteContexte {
  const valeur = useContext(Ctx);
  if (!valeur) {
    // Défaut sûr si utilisé hors provider (ne doit pas arriver).
    return {
      charge: true,
      authActive: false,
      erreurConfig: null,
      compte: null,
      comptes: [],
      rafraichir: async () => {},
      deconnecter: async () => {},
    };
  }
  return valeur;
}

// ---------------------------------------------------------------------------
// Provider + garde
// ---------------------------------------------------------------------------

export function CompteGarde({ children }: { children: React.ReactNode }) {
  const [etat, setEtat] = useState<ReponseAuth | null>(null);
  const [erreurReseau, setErreurReseau] = useState<string | null>(null);

  const rafraichir = useCallback(async () => {
    try {
      const res = await fetch("/api/auth/compte", { cache: "no-store" });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = (await res.json()) as ReponseAuth;
      setEtat(data);
      setErreurReseau(null);
    } catch (e) {
      setErreurReseau(e instanceof Error ? e.message : "Erreur inconnue.");
    }
  }, []);

  const deconnecter = useCallback(async () => {
    try {
      await fetch("/api/auth/compte", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "logout" }),
      });
    } finally {
      await rafraichir();
    }
  }, [rafraichir]);

  useEffect(() => {
    void rafraichir();
  }, [rafraichir]);

  const contexte = useMemo<CompteContexte>(
    () => ({
      charge: etat === null,
      authActive: etat?.authActive ?? false,
      erreurConfig: etat?.erreurConfig ?? null,
      compte: etat?.compte ?? null,
      comptes: etat?.comptes ?? [],
      rafraichir,
      deconnecter,
    }),
    [etat, rafraichir, deconnecter]
  );

  return <Ctx.Provider value={contexte}>{rendre(children, contexte, erreurReseau)}</Ctx.Provider>;
}

/** Décide de l'écran : écluse (chargement) / connexion / application. */
function rendre(
  children: React.ReactNode,
  ctx: CompteContexte,
  erreurReseau: string | null
) {
  // Lecture de l'état d'authentification en cours : écluse discrète pour
  // éviter un flash de l'application avant l'écran de connexion.
  if (ctx.charge) return <Ecluse chargement erreurReseau={erreurReseau} />;
  // Auth active + personne connecté → écran de connexion.
  if (ctx.authActive && !ctx.compte) return <EcranConnexion />;
  // Sinon (pas d'auth, ou déjà connecté) → application normale.
  return <>{children}</>;
}

/** Écluse de chargement (logo + pastille). */
function Ecluse({
  chargement,
  erreurReseau,
}: {
  chargement: boolean;
  erreurReseau: string | null;
}) {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-zinc-100 p-6 dark:bg-zinc-950">
      <img
        src="/logo-clement.png"
        alt="Clément Design"
        className="h-8 w-auto dark:hidden"
        width={272}
        height={32}
      />
      <img
        src="/logo-clement-blanc.png"
        alt="Clément Design"
        className="hidden h-8 w-auto dark:block"
        width={272}
        height={32}
      />
      {chargement ? (
        <div className="flex items-center gap-2 text-sm text-zinc-500 dark:text-zinc-400">
          <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
          Ouverture de l&apos;espace de travail…
        </div>
      ) : (
        erreurReseau && (
          <div className="max-w-sm rounded-md border border-red-300 bg-red-50 p-3 text-center text-sm text-red-800 dark:border-red-500/40 dark:bg-red-950/40 dark:text-red-300">
            Connexion au serveur impossible ({erreurReseau}).{" "}
            <Button variant="outline" size="sm" className="mt-2" onClick={() => window.location.reload()}>
              Réessayer
            </Button>
          </div>
        )
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Écran de connexion
// ---------------------------------------------------------------------------

/**
 * Pays (ou groupe) déduit du libellé d'un site : préfixe avant le tiret
 * (« France — Clément Design (Carros) » → France, « Tunisie — NASSTEX » →
 * Tunisie). Sans préfixe reconnaissable, le libellé complet sert de groupe.
 * Purement présentationnel : aucun impact sur les droits ni sur l'API.
 */
function clePays(siteLabel: string): string {
  const avant = siteLabel.split(/[—–]/)[0]?.trim() ?? "";
  const brut = avant || siteLabel.trim();
  const sansAccent = brut
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");
  if (sansAccent.includes("france")) return "France";
  if (sansAccent.includes("tunis")) return "Tunisie";
  return brut ? brut.charAt(0).toUpperCase() + brut.slice(1) : brut;
}

/** Nom du site sans le préfixe pays (« Tunisie — NASSTEX » → « NASSTEX »). */
function nomCourtSite(siteLabel: string): string {
  const morceaux = siteLabel.split(/[—–]/);
  const suffixe = morceaux.slice(1).join("—").trim();
  return suffixe || siteLabel.trim();
}

/** Petit drapeau français (bandes bleu-blanc-rouge) — purement décoratif. */
function DrapeauFrance({ className = "h-5 w-7" }: { className?: string }) {
  return (
    <span
      className={`flex shrink-0 overflow-hidden rounded-[3px] border border-zinc-300/70 shadow-sm dark:border-zinc-600/70 ${className}`}
      aria-hidden="true"
    >
      <span className="w-1/3 bg-[#002395]" />
      <span className="w-1/3 bg-white" />
      <span className="w-1/3 bg-[#ED2939]" />
    </span>
  );
}

/** Petit drapeau tunisien (fond rouge, disque blanc, croissant + étoile). */
function DrapeauTunisie({ className = "h-5 w-7" }: { className?: string }) {
  return (
    <span
      className={`relative flex shrink-0 items-center justify-center overflow-hidden rounded-[3px] border border-zinc-300/70 bg-[#E70013] shadow-sm dark:border-zinc-600/70 ${className}`}
      aria-hidden="true"
    >
      <span className="flex h-[62%] w-[62%] items-center justify-center rounded-full bg-white">
        <span className="relative h-[74%] w-[74%]">
          <span className="absolute inset-0 rounded-full bg-[#E70013]" />
          <span className="absolute left-[26%] top-0 h-full w-full rounded-full bg-white" />
          <Star className="absolute right-[-6%] top-1/2 h-[48%] w-[48%] -translate-y-1/2 fill-[#E70013] text-[#E70013]" />
        </span>
      </span>
    </span>
  );
}

/**
 * Écran de connexion en trois temps :
 *  1. le pays (France ou Tunisie, déduit des libellés des sites) ;
 *  2. en France : le compte parmi les 3 de Carros · en Tunisie : l'usine
 *     entre NASSTEX et Archipel (son compte unique est implicite) ;
 *  3. le code d'accès.
 * Uniquement cosmétique : aucune incidence sur les droits ni sur l'API.
 */
export function EcranConnexion() {
  const { comptes, rafraichir, erreurConfig } = useCompte();
  const [paysChoisi, setPaysChoisi] = useState<string | null>(null);
  const [siteChoisi, setSiteChoisi] = useState<string | null>(null);
  const [choisi, setChoisi] = useState<string | null>(null);
  const [code, setCode] = useState("");
  const [enCours, setEnCours] = useState(false);
  const [erreur, setErreur] = useState<string | null>(null);

  /** Pays distincts déduits des comptes, dans l'ordre de la configuration. */
  const paysListe = useMemo(() => {
    const vus: string[] = [];
    for (const c of comptes) {
      const p = clePays(c.siteLabel);
      if (!vus.includes(p)) vus.push(p);
    }
    return vus;
  }, [comptes]);

  /** Nombre de comptes par pays (mention sous le nom du pays). */
  const nbComptesPays = useMemo(() => {
    const map = new Map<string, number>();
    for (const c of comptes) {
      const p = clePays(c.siteLabel);
      map.set(p, (map.get(p) ?? 0) + 1);
    }
    return map;
  }, [comptes]);

  /** Pays effectif : choisi, ou l'unique pays configuré (étape masquée). */
  const paysEffectif = paysChoisi ?? (paysListe.length === 1 ? paysListe[0] : null);

  /** Sociétés (sites) du pays choisi, dans l'ordre de configuration. */
  const sitesDuPays = useMemo(() => {
    const map = new Map<string, ComptePublic[]>();
    if (paysEffectif) {
      for (const c of comptes) {
        if (clePays(c.siteLabel) !== paysEffectif) continue;
        const liste = map.get(c.siteLabel) ?? [];
        liste.push(c);
        map.set(c.siteLabel, liste);
      }
    }
    return [...map.entries()].map(([site, liste]) => ({ site, comptes: liste }));
  }, [comptes, paysEffectif]);

  /** Un seul site dans le pays → étape « société » masquée (France). */
  const unSeulSite = sitesDuPays.length === 1;
  const siteEffectif = unSeulSite ? (sitesDuPays[0]?.site ?? null) : siteChoisi;
  const comptesDuSite = siteEffectif
    ? (sitesDuPays.find((s) => s.site === siteEffectif)?.comptes ?? [])
    : [];
  /** Compte effectif : choisi à l'écran, ou l'unique compte du site choisi
   * (usines tunisiennes : choisir l'usine suffit, son compte est implicite). */
  const compteChoisi =
    comptes.find((c) => c.identifiant === choisi) ??
    (comptesDuSite.length === 1 ? comptesDuSite[0] : null);

  function choisirPays(p: string) {
    setPaysChoisi(p);
    setSiteChoisi(null);
    setChoisi(null);
    setCode("");
    setErreur(null);
  }

  function choisirSite(site: string) {
    setSiteChoisi(site);
    setChoisi(null);
    setCode("");
    setErreur(null);
  }

  function choisirCompte(id: string) {
    setChoisi(id);
    setCode("");
    setErreur(null);
  }

  /** Icône par rôle (compte / badge d'en-tête). */
  function iconeRole(role: ComptePublic["role"]) {
    switch (role) {
      case "stock":
        return Boxes;
      case "achats":
        return ShoppingCart;
      case "france":
        return Building2;
      default:
        return Factory;
    }
  }

  async function seConnecter(e: React.FormEvent) {
    e.preventDefault();
    if (!compteChoisi || !code.trim()) return;
    setEnCours(true);
    setErreur(null);
    try {
      const res = await fetch("/api/auth/compte", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "login",
          identifiant: compteChoisi.identifiant,
          code,
        }),
      });
      const data = (await res.json()) as { error?: string };
      if (!res.ok) {
        setErreur(data.error ?? "Connexion impossible.");
        return;
      }
      await rafraichir();
    } catch {
      setErreur("Connexion au serveur impossible. Vérifiez le réseau.");
    } finally {
      setEnCours(false);
    }
  }

  // Numérotation automatique des étapes (1, 2, 3) selon le chemin choisi :
  // France → pays, compte, code · Tunisie → pays, usine, code.
  let numero = 0;
  const etape = () => ++numero;

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-zinc-100 px-4 py-10 dark:bg-zinc-950">
      <div className="w-full max-w-md">
        {/* Logo + titre */}
        <div className="mb-6 flex flex-col items-center gap-3 text-center">
          <img
            src="/logo-clement.png"
            alt="Clément Design — Le Couturier des Cuisiniers"
            className="h-9 w-auto dark:hidden"
            width={272}
            height={32}
          />
          <img
            src="/logo-clement-blanc.png"
            alt="Clément Design — Le Couturier des Cuisiniers"
            className="hidden h-9 w-auto dark:block"
            width={272}
            height={32}
          />
          <div>
            <h1 className="text-xl font-bold tracking-tight text-zinc-900 dark:text-zinc-50">
              Espace de travail sécurisé
            </h1>
            <p className="mt-1 text-sm text-zinc-500 dark:text-zinc-400">
              Identifiez-vous : votre production (réception, étiquettes,
              colisage) sera signée de votre nom dans la base partagée.
            </p>
          </div>
        </div>

        {/* Alerte si cloud.config.json illisible */}
        {erreurConfig && (
          <div
            role="alert"
            className="mb-4 rounded-lg border border-amber-300 bg-amber-50 p-3 text-xs leading-relaxed text-amber-800 dark:border-amber-500/40 dark:bg-amber-950/40 dark:text-amber-300"
          >
            <span className="font-semibold">Configuration :</span> {erreurConfig}
          </div>
        )}

        <form
          onSubmit={(e) => void seConnecter(e)}
          className="rounded-2xl border border-zinc-200 bg-white p-5 shadow-lg dark:border-zinc-800 dark:bg-zinc-900"
        >
          {/* Étape 1 — le pays (France / Tunisie ; masquée si un seul pays) */}
          <fieldset className="mb-4">
            <legend className="mb-2 text-sm font-semibold text-zinc-700 dark:text-zinc-300">
              {etape()}. Votre pays
            </legend>
            {paysListe.length === 0 ? (
              <p className="rounded-lg border border-dashed p-3 text-sm text-zinc-500 dark:text-zinc-400">
                Aucun compte configuré — contactez Clément Design.
              </p>
            ) : (
              <div className="grid gap-2 sm:grid-cols-2" role="radiogroup" aria-label="Choisir le pays">
                {paysListe.map((p) => {
                  const actif = p === paysEffectif;
                  const nb = nbComptesPays.get(p) ?? 0;
                  return (
                    <button
                      key={p}
                      type="button"
                      role="radio"
                      aria-checked={actif}
                      onClick={() => choisirPays(p)}
                      className={`flex min-h-11 items-center gap-2.5 rounded-xl border px-3 py-2.5 text-left transition-colors ${
                        actif
                          ? "border-amber-500 bg-amber-50 ring-1 ring-amber-500 dark:bg-amber-950/40"
                          : "border-zinc-200 bg-white hover:border-amber-300 hover:bg-amber-50/50 dark:border-zinc-700 dark:bg-zinc-950 dark:hover:bg-amber-950/20"
                      }`}
                    >
                      {p === "France" ? (
                        <DrapeauFrance />
                      ) : p === "Tunisie" ? (
                        <DrapeauTunisie />
                      ) : (
                        <span
                          className={`flex h-5 w-7 shrink-0 items-center justify-center rounded-[3px] border border-zinc-300/70 shadow-sm dark:border-zinc-600/70 ${
                            actif ? "bg-amber-600" : "bg-zinc-100 dark:bg-zinc-800"
                          }`}
                        >
                          <Globe
                            className={`h-3.5 w-3.5 ${
                              actif ? "text-white" : "text-zinc-500 dark:text-zinc-400"
                            }`}
                            aria-hidden="true"
                          />
                        </span>
                      )}
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-sm font-semibold text-zinc-900 dark:text-zinc-100">
                          {p}
                        </span>
                        <span className="block text-xs text-zinc-500 dark:text-zinc-400">
                          {nb} compte{nb > 1 ? "s" : ""}
                        </span>
                      </span>
                      {actif && <ShieldCheck className="h-4 w-4 shrink-0 text-amber-600" aria-hidden="true" />}
                    </button>
                  );
                })}
              </div>
            )}
          </fieldset>

          {/* Étape 2 — l'usine / la société (uniquement si le pays en a
              plusieurs : en Tunisie, choisir entre NASSTEX et Archipel) */}
          {paysEffectif && !unSeulSite && (
            <fieldset className="mb-4">
              <legend className="mb-2 text-sm font-semibold text-zinc-700 dark:text-zinc-300">
                {etape()}. {paysEffectif === "Tunisie" ? "Votre usine" : "Votre société"}
              </legend>
              <div className="grid gap-2 sm:grid-cols-2" role="radiogroup" aria-label="Choisir l'usine">
                {sitesDuPays.map(({ site, comptes: liste }) => {
                  const actif = site === siteEffectif;
                  return (
                    <button
                      key={site}
                      type="button"
                      role="radio"
                      aria-checked={actif}
                      onClick={() => choisirSite(site)}
                      title={site}
                      className={`flex min-h-11 items-center gap-2.5 rounded-xl border px-3 py-2.5 text-left transition-colors ${
                        actif
                          ? "border-amber-500 bg-amber-50 ring-1 ring-amber-500 dark:bg-amber-950/40"
                          : "border-zinc-200 bg-white hover:border-amber-300 hover:bg-amber-50/50 dark:border-zinc-700 dark:bg-zinc-950 dark:hover:bg-amber-950/20"
                      }`}
                    >
                      <span
                        className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-lg ${
                          actif
                            ? "bg-amber-600 text-white"
                            : "bg-zinc-100 text-zinc-500 dark:bg-zinc-800 dark:text-zinc-400"
                        }`}
                      >
                        <Factory className="h-4 w-4" aria-hidden="true" />
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-sm font-semibold text-zinc-900 dark:text-zinc-100">
                          {nomCourtSite(site)}
                        </span>
                        <span className="block text-xs text-zinc-500 dark:text-zinc-400">
                          {liste.length} compte{liste.length > 1 ? "s" : ""}
                        </span>
                      </span>
                      {actif && <ShieldCheck className="h-4 w-4 shrink-0 text-amber-600" aria-hidden="true" />}
                    </button>
                  );
                })}
              </div>
            </fieldset>
          )}

          {/* Étape suivante — le compte (en France : Achats, Youness, William ;
              masqué quand l'usine choisie n'a qu'un compte, il est implicite) */}
          {siteEffectif && comptesDuSite.length > 1 && (
            <fieldset className="mb-4">
              <legend className="mb-2 text-sm font-semibold text-zinc-700 dark:text-zinc-300">
                {etape()}. Votre compte
              </legend>
              <div className="grid gap-2" role="radiogroup" aria-label="Choisir le compte">
                {comptesDuSite.map((c) => {
                  const actif = c.identifiant === compteChoisi?.identifiant;
                  const Icone = iconeRole(c.role);
                  return (
                    <button
                      key={c.identifiant}
                      type="button"
                      role="radio"
                      aria-checked={actif}
                      onClick={() => choisirCompte(c.identifiant)}
                      className={`flex min-h-11 w-full items-center gap-3 rounded-xl border px-3 py-2.5 text-left transition-colors ${
                        actif
                          ? "border-amber-500 bg-amber-50 ring-1 ring-amber-500 dark:bg-amber-950/40"
                          : "border-zinc-200 bg-white hover:border-amber-300 hover:bg-amber-50/50 dark:border-zinc-700 dark:bg-zinc-950 dark:hover:bg-amber-950/20"
                      }`}
                    >
                      <span
                        className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-lg ${
                          actif
                            ? "bg-amber-600 text-white"
                            : "bg-zinc-100 text-zinc-500 dark:bg-zinc-800 dark:text-zinc-400"
                        }`}
                      >
                        <Icone className="h-4 w-4" aria-hidden="true" />
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-sm font-semibold text-zinc-900 dark:text-zinc-100">
                          {c.nom}
                        </span>
                        <span className="block truncate text-xs text-zinc-500 dark:text-zinc-400">
                          {libelleRole(c.role)}
                        </span>
                      </span>
                      {actif && <ShieldCheck className="h-4 w-4 shrink-0 text-amber-600" aria-hidden="true" />}
                    </button>
                  );
                })}
              </div>
            </fieldset>
          )}

          <div className="mb-4 grid gap-1.5">
            <Label htmlFor="compte-code" className="text-sm font-semibold text-zinc-700 dark:text-zinc-300">
              {etape()}. Votre code d&apos;accès
            </Label>
            <Input
              id="compte-code"
              type="password"
              inputMode="text"
              autoComplete="current-password"
              value={code}
              onChange={(e) => setCode(e.target.value)}
              placeholder={
                compteChoisi
                  ? `Code de ${compteChoisi.nom}…`
                  : paysEffectif
                    ? unSeulSite
                      ? "Choisissez d'abord votre compte"
                      : paysEffectif === "Tunisie"
                        ? "Choisissez d'abord votre usine"
                        : "Choisissez d'abord votre société"
                    : "Choisissez d'abord votre pays"
              }
              disabled={!compteChoisi || enCours}
              className="h-11"
              autoFocus
            />
          </div>

          {erreur && (
            <p
              role="alert"
              className="mb-3 rounded-md border border-red-300 bg-red-50 px-3 py-2 text-sm text-red-800 dark:border-red-500/40 dark:bg-red-950/40 dark:text-red-300"
            >
              {erreur}
            </p>
          )}

          <Button
            type="submit"
            disabled={!compteChoisi || !code.trim() || enCours}
            className="h-11 w-full bg-amber-600 text-base font-semibold text-white hover:bg-amber-700"
          >
            {enCours ? (
              <Loader2 className="h-5 w-5 animate-spin" aria-hidden="true" />
            ) : (
              <LockKeyhole className="h-5 w-5" aria-hidden="true" />
            )}
            Se connecter
          </Button>
        </form>

        <p className="mt-4 text-center text-[11px] leading-relaxed text-zinc-400 dark:text-zinc-600">
          Les accès sont créés et gérés par Clément Design (fichier
          cloud.config.json sur le serveur). Oubli de code : contactez le
          service Achats.
        </p>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Badge d'en-tête (identité + déconnexion)
// ---------------------------------------------------------------------------

/** Pastille d'en-tête : compte connecté + bouton de déconnexion. */
export function BadgeCompte() {
  const { authActive, compte, deconnecter } = useCompte();
  const [enCours, setEnCours] = useState(false);
  if (!authActive || !compte) return null;

  const Icone =
    compte.role === "stock"
      ? Boxes
      : compte.role === "achats"
        ? ShoppingCart
        : compte.role === "france"
          ? Building2
          : Factory;
  const couleurIcone =
    compte.role === "stock"
      ? "text-sky-400"
      : compte.role === "achats" || compte.role === "france"
        ? "text-emerald-400"
        : "text-amber-400";

  return (
    <div
      className="flex items-center gap-1.5 rounded-full border border-zinc-700 bg-zinc-800/80 py-1 pl-2.5 pr-1 text-white"
      title={`${compte.nom} — ${compte.siteLabel}`}
    >
      <Icone
        className={`h-3.5 w-3.5 shrink-0 ${couleurIcone}`}
        aria-hidden="true"
      />
      <span className="max-w-[9rem] truncate text-xs font-semibold sm:max-w-[12rem]">
        {compte.nom}
      </span>
      <Tooltip>
        <TooltipTrigger asChild>
          <Button
            variant="ghost"
            size="icon"
            aria-label={`Se déconnecter du compte ${compte.nom}`}
            disabled={enCours}
            onClick={() => {
              setEnCours(true);
              void deconnecter().finally(() => setEnCours(false));
            }}
            className="h-6 w-6 rounded-full text-zinc-400 hover:bg-zinc-700 hover:text-white"
          >
            {enCours ? (
              <Loader2 className="h-3 w-3 animate-spin" aria-hidden="true" />
            ) : (
              <LogOut className="h-3 w-3" aria-hidden="true" />
            )}
          </Button>
        </TooltipTrigger>
        <TooltipContent>
          <p>Se déconnecter ({compte.siteLabel})</p>
        </TooltipContent>
      </Tooltip>
    </div>
  );
}
