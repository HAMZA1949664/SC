"use client";

/**
 * Espace de travail « Colisage » — réservé au service achats (rôle
 * « achats »). Transforme la LISTE DES CODES scannés par le stock à la
 * réception (collée ou importée depuis le fichier « codes_scannes_….txt »)
 * en colisage regroupé : OF → modèle → couleur → taille, quantités comptées
 * automatiquement (un code rescanné = une pièce de plus).
 *
 * La réception (scan des articles, pointage attendu / reçu / écart) est
 * gérée dans l'onglet Réception par le stock — espace volontairement séparé.
 */

import { useMemo, useRef, useState } from "react";
import {
  AlertTriangle,
  Boxes,
  CheckCircle2,
  ClipboardList,
  Copy,
  FileSpreadsheet,
  FileUp,
  Hash,
  Loader2,
  Package,
  ScanLine,
  Trash2,
} from "lucide-react";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { useToast } from "@/hooks/use-toast";
import {
  construireCsvColisage,
  developperEntrees,
  extraireEntrees,
  horodatageFichier,
  MAX_CODES_COLISAGE,
  totalPieces,
  TAILLE_MAX_TEXTE_COLISAGE,
  type ResultatColisage,
} from "@/lib/colisage";

/** Nombre maximal de lignes rendues dans le tableau (au-delà : bouton « tout afficher »). */
const MAX_LIGNES_RENDUES = 400;

export function ColisageWorkspace() {
  const { toast } = useToast();

  const [texteBrut, setTexteBrut] = useState("");
  const [ofsSaisis, setOfsSaisis] = useState("");
  const [resultat, setResultat] = useState<ResultatColisage | null>(null);
  const [enCours, setEnCours] = useState(false);
  const [erreur, setErreur] = useState<string | null>(null);
  const [depotActif, setDepotActif] = useState(false);
  const [toutAfficher, setToutAfficher] = useState(false);
  const [tableCopiee, setTableCopiee] = useState(false);

  const fichierRef = useRef<HTMLInputElement>(null);
  const compteurDepot = useRef(0);

  /** Pièces détectées dans le texte collé / importé (quantités « ×N » comprises). */
  const piecesDetectees = useMemo(
    () => totalPieces(extraireEntrees(texteBrut)),
    [texteBrut]
  );

  const peutGenerer = piecesDetectees > 0 && !enCours;

  // -------------------------------------------------------------------------
  // Import fichier : extraction des codes 13 chiffres (liste douchette,
  // export multi-colonnes, présence ou non d'en-tête) + glisser-déposer.
  // -------------------------------------------------------------------------
  async function importerFichier(fichier: File) {
    if (fichier.size > TAILLE_MAX_TEXTE_COLISAGE) {
      toast({
        title: "Fichier trop volumineux",
        description: `Taille maximale : ${Math.round(TAILLE_MAX_TEXTE_COLISAGE / 1_000_000)} Mo.`,
        variant: "destructive",
      });
      return;
    }
    const estTexte =
      /\.txt$|\.csv$|\.text$/i.test(fichier.name) || fichier.type.startsWith("text/");
    if (!estTexte) {
      toast({
        title: "Format non pris en charge",
        description: "Importez un fichier .txt ou .csv contenant les codes-barres.",
        variant: "destructive",
      });
      return;
    }
    try {
      const contenu = await fichier.text();
      const entrees = extraireEntrees(contenu);
      if (entrees.length === 0) {
        toast({
          title: "Aucun code-barres trouvé",
          description: `Aucun code à 13 chiffres détecté dans « ${fichier.name} ».`,
          variant: "destructive",
        });
        return;
      }
      setTexteBrut((precedent) => {
        const base = precedent.trim();
        // Les quantités « ×N » éventuelles du fichier sont conservées.
        const ajoute = entrees
          .map((e) => (e.quantite > 1 ? `${e.code}×${e.quantite}` : e.code))
          .join("\n");
        return base ? `${base}\n${ajoute}` : ajoute;
      });
      setResultat(null);
      setErreur(null);
      toast({
        title: `${totalPieces(entrees).toLocaleString("fr-FR")} pièce(s) importée(s)`,
        description: `Depuis « ${fichier.name} » — ${entrees.length.toLocaleString("fr-FR")} ligne(s), quantités « ×N » conservées. Vérifiez le total puis générez le colisage.`,
      });
    } catch {
      toast({
        title: "Lecture impossible",
        description: "Le fichier n'a pas pu être lu.",
        variant: "destructive",
      });
    }
  }

  // -------------------------------------------------------------------------
  // Génération : envoi des codes au serveur (décodage SPE inclus)
  // -------------------------------------------------------------------------
  async function generer() {
    const entrees = extraireEntrees(texteBrut);
    if (entrees.length === 0) {
      toast({
        title: "Aucun code-barres à analyser",
        description: "Collez d'abord la liste des codes scannés à la réception, ou importez le fichier.",
        variant: "destructive",
      });
      return;
    }
    // Les quantités « ×N » sont développées en occurrences : le contrat des
    // API reste inchangé (« code×25 » équivaut à 25 scans du même code).
    const codes = developperEntrees(entrees);
    if (codes.length > MAX_CODES_COLISAGE) {
      toast({
        title: "Trop de pièces dans le lot",
        description: `${codes.length.toLocaleString("fr-FR")} pièce(s) — maximum ${MAX_CODES_COLISAGE.toLocaleString("fr-FR")}. Réduisez les quantités « ×N » ou traitez en plusieurs lots.`,
        variant: "destructive",
      });
      return;
    }
    setEnCours(true);
    setErreur(null);
    try {
      const ofs = ofsSaisis
        .split(/[\s,;]+/)
        .map((o) => o.trim())
        .filter(Boolean);
      const reponse = await fetch("/api/colisage", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ codes, ...(ofs.length > 0 ? { ofs } : {}) }),
      });
      const corps = await reponse.json().catch(() => null);
      if (!reponse.ok) {
        const message =
          (corps && typeof corps.error === "string" && corps.error) ||
          "Échec de la génération du colisage.";
        setErreur(message);
        toast({ title: "Colisage impossible", description: message, variant: "destructive" });
        return;
      }
      setResultat(corps as ResultatColisage);
      setToutAfficher(false);
      const s = (corps as ResultatColisage).stats;
      toast({
        title: "Colisage généré",
        description: `${s.total.toLocaleString("fr-FR")} pièce(s) analysée(s) en ${s.dureeMs} ms — ${s.skus.toLocaleString("fr-FR")} ligne(s), ${s.inconnusQuantite} inconnu(s).`,
      });
    } catch {
      const message = "Connexion au serveur impossible. Réessayez.";
      setErreur(message);
      toast({ title: "Erreur réseau", description: message, variant: "destructive" });
    } finally {
      setEnCours(false);
    }
  }

  // -------------------------------------------------------------------------
  // Exports : CSV (Excel) et copie du tableau (presse-papiers, TSV)
  // -------------------------------------------------------------------------
  function telechargerCsv() {
    if (!resultat || resultat.lignes.length === 0) return;
    const blob = new Blob([construireCsvColisage(resultat.lignes)], {
      type: "text/csv;charset=utf-8",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `colisage_${horodatageFichier()}.csv`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
    toast({
      title: "Colisage exporté (CSV)",
      description: `${resultat.lignes.length.toLocaleString("fr-FR")} ligne(s) — colisage_${horodatageFichier()}.csv`,
    });
  }

  async function copierTableau() {
    if (!resultat || resultat.lignes.length === 0) return;
    const tsv = ["OF\tModèle\tCouleur\tTaille\tQté\tManche"]
      .concat(
        resultat.lignes.map(
          (l) => `${l.of || "-"}\t${l.modele}\t${l.couleur}\t${l.taille}\t${l.quantite}\t${l.manche || "-"}`
        )
      )
      .join("\n");
    try {
      await navigator.clipboard.writeText(tsv);
      setTableCopiee(true);
      window.setTimeout(() => setTableCopiee(false), 1600);
      toast({
        title: "Tableau copié",
        description: "Collez-le directement dans Excel ou votre ERP.",
      });
    } catch {
      toast({
        title: "Copie impossible",
        description: "Le navigateur a refusé l'accès au presse-papiers.",
        variant: "destructive",
      });
    }
  }

  function vider() {
    setTexteBrut("");
    setOfsSaisis("");
    setResultat(null);
    setErreur(null);
    setToutAfficher(false);
  }

  // Sous-totaux par OF (colonne OF : « 078594 · 152 p. »)
  const sousTotauxOf = useMemo(() => {
    const map = new Map<string, number>();
    for (const l of resultat?.lignes ?? []) {
      if (!l.of) continue;
      map.set(l.of, (map.get(l.of) ?? 0) + l.quantite);
    }
    return map;
  }, [resultat]);

  const lignesRendues =
    resultat === null || toutAfficher
      ? (resultat?.lignes ?? [])
      : resultat.lignes.slice(0, MAX_LIGNES_RENDUES);

  const nbCachees = (resultat?.lignes.length ?? 0) - lignesRendues.length;

  return (
    <div className="space-y-6" aria-label="Génération de colisage">
      {/* ------------------------- Saisie des codes ------------------------- */}
      <Card
        className={`card-lift relative transition-shadow ${
          depotActif ? "ring-2 ring-amber-500/70 ring-offset-2 ring-offset-background dark:ring-offset-zinc-950" : ""
        }`}
        onDragEnter={(e) => {
          e.preventDefault();
          compteurDepot.current += 1;
          setDepotActif(true);
        }}
        onDragOver={(e) => e.preventDefault()}
        onDragLeave={() => {
          compteurDepot.current -= 1;
          if (compteurDepot.current <= 0) {
            compteurDepot.current = 0;
            setDepotActif(false);
          }
        }}
        onDrop={async (e) => {
          e.preventDefault();
          compteurDepot.current = 0;
          setDepotActif(false);
          const fichier = e.dataTransfer.files?.[0];
          if (fichier) await importerFichier(fichier);
        }}
      >
        {depotActif && (
          <div
            className="depot-voile pointer-events-none absolute inset-0 z-20 flex items-center justify-center rounded-xl border-2 border-dashed border-amber-500 bg-amber-50/90 dark:bg-zinc-950/90"
            aria-hidden="true"
          >
            <div className="flex items-center gap-3 text-amber-800 dark:text-amber-300">
              <FileUp className="depot-icone h-8 w-8" />
              <p className="text-lg font-bold">Déposez le fichier de codes ici</p>
            </div>
          </div>
        )}

        <CardHeader className="pb-4">
          <CardTitle className="flex items-center justify-between gap-2 text-base">
            <span className="flex items-center gap-2">
              <Package className="h-4 w-4 text-amber-600" aria-hidden="true" />
              Génération du colisage
            </span>
            <Badge variant="secondary" aria-live="polite">
              {piecesDetectees.toLocaleString("fr-FR")} pièce(s) détectée(s)
            </Badge>
          </CardTitle>
          <CardDescription>
            Collez la liste des codes scannés à la réception par le stock
            (fichier <code className="rounded bg-zinc-100 px-1 font-mono text-[11px] dark:bg-zinc-800">codes_scannes_….txt</code>{" "}
            — un code par ligne, 3 000 à 4 000 lignes acceptées) ou importez-le.
            Le colisage est regroupé automatiquement :{" "}
            <strong>OF → modèle → couleur → taille</strong>, quantités comptées
            — aucune saisie ligne à ligne.
          </CardDescription>
        </CardHeader>

        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="codes-colisage">Codes-barres scannés</Label>
            <Textarea
              id="codes-colisage"
              value={texteBrut}
              onChange={(e) => {
                setTexteBrut(e.target.value);
                setResultat(null);
                setErreur(null);
              }}
              placeholder={"3700791700130\n3700791700147×12\n3700791700154\n…"}
              className="min-h-44 resize-y font-mono text-sm leading-relaxed"
              spellCheck={false}
              autoComplete="off"
            />
            <p className="flex items-start gap-1.5 text-xs text-muted-foreground">
              <ScanLine className="mt-0.5 h-3.5 w-3.5 shrink-0" aria-hidden="true" />
              <span>
                Les codes inconnus ou illisibles sont signalés mais ne bloquent
                jamais le colisage. Les doublons sont comptés comme plusieurs pièces.
                <span className="mt-1 block">
                  <strong className="font-semibold text-amber-700 dark:text-amber-400">
                    Quantité sans tout scanner&nbsp;:
                  </strong>{" "}
                  ajoutez{" "}
                  <code className="rounded bg-zinc-100 px-1 font-mono text-[11px] dark:bg-zinc-800">
                    ×N
                  </code>{" "}
                  après un code pour l&apos;enregistrer en plusieurs pièces — ex.{" "}
                  <code className="rounded bg-zinc-100 px-1 font-mono text-[11px] dark:bg-zinc-800">
                    3700791700147×12
                  </code>{" "}
                  = 12 pièces (colisage et exports inclus).
                </span>
              </span>
            </p>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="ofs-colisage">
                N° d&apos;OF du lot{" "}
                <span className="font-normal text-muted-foreground">(facultatif)</span>
              </Label>
              <Input
                id="ofs-colisage"
                value={ofsSaisis}
                onChange={(e) => setOfsSaisis(e.target.value)}
                placeholder="ex. 078594, 078910"
                className="h-10 font-mono"
                autoComplete="off"
              />
              <p className="text-xs text-muted-foreground">
                Aide au décodage des codes SPE (préfixe 99). Les OF déjà générés
                via l&apos;application sont reconnus automatiquement.
              </p>
            </div>
            <div className="flex flex-col justify-end gap-2">
              <input
                ref={fichierRef}
                type="file"
                accept=".txt,.csv,text/plain,text/csv"
                className="hidden"
                onChange={async (e) => {
                  const fichier = e.target.files?.[0];
                  if (fichier) await importerFichier(fichier);
                  e.target.value = "";
                }}
                aria-hidden="true"
                tabIndex={-1}
              />
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="outline"
                    onClick={() => fichierRef.current?.click()}
                    className="h-10 w-full"
                  >
                    <FileUp className="mr-2 h-4 w-4" aria-hidden="true" />
                    Importer un fichier de codes
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>.txt / .csv — les codes 13 chiffres sont extraits automatiquement, ou glissez le fichier sur la carte</p>
                </TooltipContent>
              </Tooltip>
              <Button
                variant="ghost"
                onClick={vider}
                disabled={!texteBrut && !resultat && !ofsSaisis}
                className="h-10 w-full"
              >
                <Trash2 className="mr-2 h-4 w-4" aria-hidden="true" />
                Tout effacer
              </Button>
            </div>
          </div>

          {erreur && (
            <p
              className="flex items-start gap-2 rounded-lg border border-red-300 bg-red-50 p-3 text-sm text-red-800 dark:border-red-500/40 dark:bg-red-950/30 dark:text-red-300"
              role="alert"
            >
              <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" />
              {erreur}
            </p>
          )}
        </CardContent>

        <CardFooter className="border-t bg-zinc-50/60 p-4 dark:bg-zinc-900/60">
          <Button
            onClick={generer}
            disabled={!peutGenerer}
            className="btn-shine h-12 w-full bg-amber-600 text-base font-semibold text-white hover:bg-amber-700"
          >
            {enCours ? (
              <Loader2 className="mr-2 h-5 w-5 animate-spin" aria-hidden="true" />
            ) : (
              <ClipboardList className="mr-2 h-5 w-5" aria-hidden="true" />
            )}
            {enCours ? "Analyse en cours…" : "Générer le colisage"}
          </Button>
        </CardFooter>
      </Card>

      {/* ------------------------- Résultat ------------------------- */}
      {resultat && (
        <Card className="card-lift">
          <CardHeader className="pb-4">
            <CardTitle className="flex items-center justify-between gap-2 text-base">
              <span className="flex items-center gap-2">
                <Boxes className="h-4 w-4 text-amber-600" aria-hidden="true" />
                Colisage regroupé
              </span>
              <span className="flex gap-1.5">
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={copierTableau}
                      className="h-8 px-2 text-xs text-zinc-500 hover:text-amber-700"
                    >
                      {tableCopiee ? (
                        <CheckCircle2 className="mr-1 h-3.5 w-3.5 text-green-600" aria-hidden="true" />
                      ) : (
                        <Copy className="mr-1 h-3.5 w-3.5" aria-hidden="true" />
                      )}
                      {tableCopiee ? "Copié" : "Copier"}
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Copier le tableau (collable dans Excel / ERP)</p>
                  </TooltipContent>
                </Tooltip>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={telechargerCsv}
                  className="h-8 px-2 text-xs text-zinc-500 hover:text-amber-700"
                >
                  <FileSpreadsheet className="mr-1 h-3.5 w-3.5" aria-hidden="true" />
                  CSV
                </Button>
              </span>
            </CardTitle>
            <CardDescription>
              Quantités comptées automatiquement — même code scanné plusieurs
              fois = plusieurs pièces.
            </CardDescription>
          </CardHeader>

          <CardContent className="space-y-4">
            {/* Statistiques du scan */}
            <dl className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              {[
                { icone: Hash, valeur: resultat.stats.total, libelle: "Codes scannés" },
                { icone: CheckCircle2, valeur: resultat.stats.reconnus, libelle: "Reconnus" },
                { icone: Boxes, valeur: resultat.stats.skus, libelle: "Lignes" },
                { icone: Package, valeur: resultat.stats.ofs, libelle: "OF identifiés" },
              ].map(({ icone: Icone, valeur, libelle }) => (
                <div
                  key={libelle}
                  className="rounded-lg border bg-white p-3 text-center dark:bg-zinc-900"
                >
                  <dd className="flex items-center justify-center gap-1.5 font-serif text-xl font-semibold tabular-nums">
                    <Icone className="h-4 w-4 text-amber-600" aria-hidden="true" />
                    {valeur.toLocaleString("fr-FR")}
                  </dd>
                  <dt className="mt-0.5 text-[11px] uppercase tracking-wide text-muted-foreground">
                    {libelle}
                  </dt>
                </div>
              ))}
            </dl>

            {/* Codes inconnus */}
            {resultat.inconnus.length > 0 && (
              <div
                className="rounded-lg border border-amber-300 bg-amber-50 p-3 dark:border-amber-500/40 dark:bg-amber-950/20"
                role="note"
              >
                <p className="flex items-center gap-2 text-sm font-semibold text-amber-800 dark:text-amber-300">
                  <AlertTriangle className="h-4 w-4 shrink-0" aria-hidden="true" />
                  {resultat.stats.inconnusQuantite} code(s) inconnu(s) —{" "}
                  {resultat.inconnus.length} référence(s) absente(s) de la base
                </p>
                <div className="mt-2 max-h-28 overflow-y-auto rounded border border-amber-200 bg-white p-2 font-mono text-xs leading-relaxed text-amber-900 dark:border-amber-500/30 dark:bg-zinc-950 dark:text-amber-200">
                  {resultat.inconnus.map((i) => (
                    <div key={i.code} className="flex justify-between gap-3">
                      <span>{i.code}</span>
                      <span className="tabular-nums">× {i.quantite}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Tableau du colisage */}
            <div className="overflow-hidden rounded-lg border">
              <div className="max-h-96 overflow-y-auto">
                <table className="w-full text-sm">
                  <caption className="sr-only">
                    Colisage regroupé par OF, modèle, couleur et taille
                  </caption>
                  <thead className="sticky top-0 z-10 bg-white shadow-[0_1px_0_0] shadow-zinc-200 dark:bg-zinc-900 dark:shadow-zinc-700">
                    <tr>
                      <th scope="col" className="px-3 py-2 text-left font-semibold">OF</th>
                      <th scope="col" className="px-3 py-2 text-left font-semibold">Modèle</th>
                      <th scope="col" className="px-3 py-2 text-left font-semibold">Couleur</th>
                      <th scope="col" className="px-3 py-2 text-left font-semibold">Taille</th>
                      <th scope="col" className="px-3 py-2 text-right font-semibold">Qté</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y">
                    {lignesRendues.map((l, idx) => {
                      const precedente = lignesRendues[idx - 1];
                      const nouveauOf = !!l.of && l.of !== (precedente?.of ?? "");
                      const finOf = l.of !== "" && lignesRendues[idx + 1]?.of !== l.of;
                      return (
                        <tr
                          key={`${l.of}|${l.modele}|${l.couleur}|${l.taille}|${l.manche}`}
                          className={`transition-colors hover:bg-amber-50/60 dark:hover:bg-amber-950/20 ${
                            nouveauOf ? "border-t-2 border-t-zinc-300 dark:border-t-zinc-600" : ""
                          }`}
                        >
                          <td className="whitespace-nowrap px-3 py-1.5 font-mono text-xs">
                            {l.of ? (
                              <span className="inline-flex flex-col leading-tight">
                                <span>{l.of}</span>
                                {finOf && (
                                  <span className="text-[10px] tabular-nums text-muted-foreground">
                                    {(sousTotauxOf.get(l.of) ?? 0).toLocaleString("fr-FR")} pièces
                                  </span>
                                )}
                              </span>
                            ) : (
                              <span className="text-muted-foreground">—</span>
                            )}
                          </td>
                          <td className="px-3 py-1.5 font-medium">{l.modele}</td>
                          <td className="px-3 py-1.5">
                            {l.couleur}
                            <span className="ml-1.5 font-mono text-[10px] text-muted-foreground">
                              {l.couleurCode}
                            </span>
                          </td>
                          <td className="px-3 py-1.5 font-mono text-xs">{l.taille}</td>
                          <td className="px-3 py-1.5 text-right font-bold tabular-nums">
                            {l.quantite}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>

            {nbCachees > 0 && (
              <div className="flex items-center justify-between gap-3 text-xs text-muted-foreground">
                <span>
                  + {nbCachees.toLocaleString("fr-FR")} ligne(s) masquée(s) pour la fluidité
                </span>
                <Button variant="outline" size="sm" onClick={() => setToutAfficher(true)}>
                  Tout afficher
                </Button>
              </div>
            )}
          </CardContent>

          <CardFooter className="flex flex-wrap items-center justify-between gap-2 border-t bg-zinc-50/60 p-4 dark:bg-zinc-900/60">
            <p className="text-xs text-muted-foreground">
              Analyse de {resultat.stats.total.toLocaleString("fr-FR")} codes en{" "}
              {resultat.stats.dureeMs} ms
              {resultat.stats.ofs > 0 &&
                ` — ${resultat.stats.ofs} OF distinct(s)`}
            </p>
            <Button
              onClick={telechargerCsv}
              className="h-10 bg-amber-600 font-semibold text-white hover:bg-amber-700"
            >
              <FileSpreadsheet className="mr-2 h-4 w-4" aria-hidden="true" />
              Exporter le colisage (CSV)
            </Button>
          </CardFooter>
        </Card>
      )}
    </div>
  );
}
