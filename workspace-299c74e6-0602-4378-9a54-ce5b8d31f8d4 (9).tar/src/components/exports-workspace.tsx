"use client";

/**
 * Espace Exports (façonnier + achats) — création du nouvel export du samedi.
 *
 * Fonctionnement demandé par Clément Design (une seule modification, le reste
 * du site inchangé) :
 *  1. Au début du nouvel export : choix du N° d'OF parmi les OF déjà générés
 *     → le système récupère automatiquement TOUTES les informations
 *     (articles/références, codes-barres, quantités, couleurs, tailles) —
 *     l'utilisateur ne ressaisit rien ;
 *  2. « Ajouter une ligne » : petit bouton secondaire pour ajouter à la main
 *     une ligne hors OF (article, quantité…) ;
 *  3. Colisage : la seule information nouvelle à saisir est le n° de colis ;
 *  4. Date : les exports partent le samedi — les deux prochains samedis
 *     sont proposés.
 */

import { useCallback, useEffect, useMemo, useState } from "react";
import {
  CalendarDays,
  Check,
  Factory,
  Hash,
  Loader2,
  Package,
  Plus,
  RefreshCw,
  Search,
  Send,
  X,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import type { ComptePublic } from "@/components/compte-garde";
import {
  type ExportListe,
  type LigneExport,
  type OfDisponible,
  formaterSamedi,
  nomCourtSite,
  prochainsSamedis,
  semaineIso,
} from "@/lib/exports";

/** Quantité maximale d'une ligne manuelle (cohérent avec le reste du site). */
const QUANTITE_MAX = 999;

/** Ligne manuelle en cours de saisie (état local du dialog). */
interface LigneManuelle {
  of: string;
  article: string;
  couleur: string;
  taille: string;
  quantite: number;
}

export function ExportsWorkspace({ compte }: { compte: ComptePublic | null }) {
  const { toast } = useToast();

  // ----- Liste des exports + OF disponibles -------------------------------
  const [exports, setExports] = useState<ExportListe[]>([]);
  const [ofs, setOfs] = useState<OfDisponible[]>([]);
  const [chargement, setChargement] = useState(true);
  const [erreur, setErreur] = useState<string | null>(null);

  // ----- Dialog « Nouvel export » ------------------------------------------
  const [dialogOuvert, setDialogOuvert] = useState(false);
  const [samedi, setSamedi] = useState("");
  const [titre, setTitre] = useState("");
  const [titreModifie, setTitreModifie] = useState(false);
  /** OF cochés pour cet export — parfois 3, parfois 5, parfois 8 par colis. */
  const [ofsChoisis, setOfsChoisis] = useState<string[]>([]);
  /** Recherche d'OF (liste longue : on retrouve un N° en tapant ses chiffres). */
  const [rechercheOf, setRechercheOf] = useState("");
  const [lignesAuto, setLignesAuto] = useState<LigneExport[]>([]);
  const [ofEnCours, setOfEnCours] = useState(false);
  const [lignesManuelles, setLignesManuelles] = useState<LigneManuelle[]>([]);
  const [numeroColis, setNumeroColis] = useState("");
  const [creationEnCours, setCreationEnCours] = useState(false);

  // ----- Formulaire « Ajouter une ligne » (secondaire) ----------------------
  const [ajoutOuvert, setAjoutOuvert] = useState(false);
  const [mArticle, setMArticle] = useState("");
  const [mCouleur, setMCouleur] = useState("");
  const [mTaille, setMTaille] = useState("");
  const [mQuantite, setMQuantite] = useState("1");

  // Les deux prochains samedis ( demandé : suffisant ).
  const samedis = useMemo(() => prochainsSamedis(2), []);

  const siteCourt = useMemo(
    () => nomCourtSite(compte?.siteLabel ?? "Façonnier"),
    [compte?.siteLabel]
  );

  /** OF filtrés par la recherche (liste longue : retrouver un N° vite). */
  const ofsFiltres = useMemo(() => {
    const q = rechercheOf.replace(/\s+/g, "");
    if (!q) return ofs;
    return ofs.filter((o) => o.of.includes(q));
  }, [ofs, rechercheOf]);

  const charger = useCallback(async () => {
    setChargement(true);
    setErreur(null);
    try {
      const res = await fetch("/api/exports", { cache: "no-store" });
      if (!res.ok) {
        const corps = (await res.json().catch(() => ({}))) as { error?: string };
        throw new Error(corps.error || `Erreur ${res.status}`);
      }
      const data = (await res.json()) as { exports: ExportListe[]; ofs: OfDisponible[] };
      setExports(data.exports ?? []);
      setOfs(data.ofs ?? []);
    } catch (e) {
      setErreur(e instanceof Error ? e.message : "Chargement des exports impossible.");
    } finally {
      setChargement(false);
    }
  }, []);

  useEffect(() => {
    void charger();
  }, [charger]);

  // Pré-remplit le titre tant que l'utilisateur ne l'a pas modifié.
  useEffect(() => {
    if (dialogOuvert && !titreModifie && samedi) {
      setTitre(`Export semaine ${semaineIso(samedi)} — ${siteCourt}`);
    }
  }, [dialogOuvert, samedi, titreModifie, siteCourt]);

  /**
   * Sélection multi-OF : cocher / décocher un OF déjà généré met à jour la
   * sélection et récupère AUTOMATIQUEMENT les lignes de tous les OF cochés
   * (articles, codes-barres, quantités, couleurs, tailles — rien à ressaisir).
   */
  const basculerOf = useCallback(
    async (ofChoisi: string) => {
      const suivants = ofsChoisis.includes(ofChoisi)
        ? ofsChoisis.filter((o) => o !== ofChoisi)
        : [...ofsChoisis, ofChoisi];
      setOfsChoisis(suivants);
      setLignesAuto([]);
      if (suivants.length === 0) return;
      setOfEnCours(true);
      try {
        const res = await fetch(
          `/api/exports?of=${encodeURIComponent(suivants.join(","))}`,
          { cache: "no-store" }
        );
        if (!res.ok) {
          const corps = (await res.json().catch(() => ({}))) as { error?: string };
          throw new Error(corps.error || `Erreur ${res.status}`);
        }
        const data = (await res.json()) as { lignes: LigneExport[] };
        setLignesAuto(data.lignes ?? []);
      } catch (e) {
        setOfsChoisis(ofsChoisis);
        toast({
          title: "OF indisponible",
          description: e instanceof Error ? e.message : "Récupération des OF impossible.",
          variant: "destructive",
        });
      } finally {
        setOfEnCours(false);
      }
    },
    [ofsChoisis, toast]
  );

  const reinitialiserDialog = useCallback(() => {
    setSamedi(samedis[0] ?? "");
    setTitre("");
    setTitreModifie(false);
    setOfsChoisis([]);
    setRechercheOf("");
    setLignesAuto([]);
    setLignesManuelles([]);
    setNumeroColis("");
    setAjoutOuvert(false);
    setMArticle("");
    setMCouleur("");
    setMTaille("");
    setMQuantite("1");
  }, [samedis]);

  const ouvrirDialog = useCallback(() => {
    reinitialiserDialog();
    setDialogOuvert(true);
  }, [reinitialiserDialog]);

  /** Ajout d'une ligne manuelle (possibilité secondaire, hors OF). */
  const ajouterLigneManuelle = useCallback(() => {
    const article = mArticle.trim();
    if (article.length === 0) {
      toast({
        title: "Article requis",
        description: "Saisissez l'article / la référence de la ligne.",
        variant: "destructive",
      });
      return;
    }
    const quantite = Math.min(QUANTITE_MAX, Math.max(1, Math.trunc(Number(mQuantite) || 1)));
    setLignesManuelles((l) => [
      ...l,
      { of: "", article, couleur: mCouleur.trim(), taille: mTaille.trim(), quantite },
    ]);
    setMArticle("");
    setMCouleur("");
    setMTaille("");
    setMQuantite("1");
    setAjoutOuvert(false);
  }, [mArticle, mCouleur, mTaille, mQuantite, toast]);

  /** Création de l'export (tables réceptions existantes + miroir cloud). */
  const creerExport = useCallback(async () => {
    if (!samedi || numeroColis.trim().length === 0) return;
    if (ofsChoisis.length === 0 && lignesManuelles.length === 0) return;
    setCreationEnCours(true);
    try {
      const res = await fetch("/api/exports", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          titre: titre.trim(),
          dateExport: samedi,
          numeroColis: numeroColis.trim(),
          ofs: ofsChoisis,
          lignesManuelles: lignesManuelles.map((l) => ({
            of: l.of || undefined,
            article: l.article,
            couleur: l.couleur || undefined,
            taille: l.taille || undefined,
            quantite: l.quantite,
          })),
        }),
      });
      if (!res.ok) {
        const corps = (await res.json().catch(() => ({}))) as { error?: string };
        throw new Error(corps.error || `Erreur ${res.status}`);
      }
      const data = (await res.json()) as { titre: string; lignes: number; quantiteTotale: number };
      toast({
        title: "Export créé",
        description: `${data.titre} — ${data.lignes} ligne(s), ${data.quantiteTotale} pièce(s), colis n° ${numeroColis.trim()}.`,
      });
      setDialogOuvert(false);
      await charger();
    } catch (e) {
      toast({
        title: "Création impossible",
        description: e instanceof Error ? e.message : "Erreur serveur.",
        variant: "destructive",
      });
    } finally {
      setCreationEnCours(false);
    }
  }, [samedi, numeroColis, ofsChoisis, lignesManuelles, titre, charger, toast]);

  /** Vide toute la sélection d'OF (et les lignes récupérées). */
  const viderSelectionOfs = useCallback(() => {
    setOfsChoisis([]);
    setLignesAuto([]);
  }, []);

  const quantiteTotale =
    lignesAuto.reduce((s, l) => s + l.quantite, 0) +
    lignesManuelles.reduce((s, l) => s + l.quantite, 0);
  const nbLignesTotal = lignesAuto.length + lignesManuelles.length;
  const peutCreer =
    samedi &&
    numeroColis.trim().length > 0 &&
    (ofsChoisis.length > 0 || lignesManuelles.length > 0) &&
    !ofEnCours &&
    !creationEnCours;

  return (
    <div className="space-y-6">
      {/* ------------------------- En-tête + liste ------------------------- */}
      <Card className="card-lift">
        <CardHeader className="flex flex-col gap-4 pb-4 sm:flex-row sm:items-start sm:justify-between">
          <div className="min-w-0">
            <CardTitle className="flex items-center gap-2 text-base">
              <Send className="h-4 w-4 text-amber-600" aria-hidden="true" />
              Exports façonnier
            </CardTitle>
            <CardDescription>
              Les exports partent le samedi : cochez le ou les OF déjà générés
              (parfois 3, parfois 5, parfois 8 par colis) — articles,
              codes-barres, quantités, couleurs et tailles sont récupérés
              automatiquement. Seul le numéro de colis est à saisir.
            </CardDescription>
          </div>
          <div className="flex shrink-0 gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => void charger()}
              disabled={chargement}
              aria-label="Rafraîchir la liste des exports"
            >
              <RefreshCw className={`h-4 w-4 ${chargement ? "animate-spin" : ""}`} aria-hidden="true" />
              <span className="sr-only sm:not-sr-only sm:ml-1">Rafraîchir</span>
            </Button>
            <Button size="sm" onClick={ouvrirDialog}>
              <Plus className="h-4 w-4" aria-hidden="true" />
              Nouvel export
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {chargement ? (
            <div className="space-y-3" aria-busy="true">
              <Skeleton className="h-20 w-full" />
              <Skeleton className="h-20 w-full" />
            </div>
          ) : erreur ? (
            <p className="rounded-md border border-red-200 bg-red-50 p-3 text-sm text-red-700 dark:border-red-900 dark:bg-red-950/40 dark:text-red-300">
              {erreur}
            </p>
          ) : exports.length === 0 ? (
            <p className="text-sm text-zinc-500 dark:text-zinc-400">
              Aucun export pour l&apos;instant. Cliquez sur « Nouvel export » :
              cochez le ou les OF déjà générés — tout est récupéré
              automatiquement —, saisissez le numéro de colis, c&apos;est tout.
            </p>
          ) : (
            <ul className="space-y-3" aria-label="Liste des exports">
              {exports.map((ex) => (
                <li key={ex.id}>
                  <details className="group rounded-lg border bg-white transition-colors dark:bg-zinc-900 [&_summary::-webkit-details-marker]:hidden">
                    <summary className="flex cursor-pointer flex-wrap items-center gap-2 p-3 hover:bg-amber-50/60 dark:hover:bg-amber-950/20">
                      <span className="min-w-0 flex-1 truncate text-sm font-semibold">
                        {ex.titre}
                      </span>
                      <Badge variant="outline" className="gap-1 whitespace-nowrap">
                        <CalendarDays className="h-3 w-3" aria-hidden="true" />
                        {formaterSamedi(ex.dateExport)}
                      </Badge>
                      <Badge variant="secondary" className="gap-1 whitespace-nowrap">
                        <Hash className="h-3 w-3" aria-hidden="true" />
                        Colis n° {ex.numeroColis}
                      </Badge>
                      <Badge
                        variant="outline"
                        className={
                          ex.statut === "cloturee"
                            ? "whitespace-nowrap border-zinc-300 text-zinc-500"
                            : "whitespace-nowrap border-emerald-300 text-emerald-700 dark:border-emerald-800 dark:text-emerald-300"
                        }
                      >
                        {ex.statut === "cloturee" ? "Clôturé" : "En préparation"}
                      </Badge>
                    </summary>
                    <div className="border-t px-3 pb-3 pt-2">
                      <p className="mb-2 text-xs text-zinc-500 dark:text-zinc-400">
                        {ex.siteLabel ? `${ex.siteLabel} · ` : ""}
                        {ex.lignes.length} ligne(s) · {ex.quantiteTotale} pièce(s)
                        {ex.creeParNom ? ` · créé par ${ex.creeParNom}` : ""}
                      </p>
                      <div className="max-h-64 overflow-y-auto rounded-md border">
                        <table className="w-full text-xs">
                          <thead className="sticky top-0 bg-zinc-50 text-left text-zinc-500 dark:bg-zinc-800 dark:text-zinc-400">
                            <tr>
                              <th className="px-2 py-1.5 font-medium">OF</th>
                              <th className="px-2 py-1.5 font-medium">Article / modèle</th>
                              <th className="px-2 py-1.5 font-medium">Couleur</th>
                              <th className="px-2 py-1.5 font-medium">Taille</th>
                              <th className="px-2 py-1.5 text-right font-medium">Qté</th>
                            </tr>
                          </thead>
                          <tbody>
                            {ex.lignes.map((l, i) => (
                              <tr key={i} className="border-t dark:border-zinc-800">
                                <td className="px-2 py-1.5 font-mono">{l.of || "—"}</td>
                                <td className="px-2 py-1.5">{l.modele}</td>
                                <td className="px-2 py-1.5">{l.couleur}</td>
                                <td className="px-2 py-1.5">{l.taille}</td>
                                <td className="px-2 py-1.5 text-right font-semibold">{l.quantite}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </details>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>

      {/* --------------------- Dialog : nouvel export --------------------- */}
      <Dialog
        open={dialogOuvert}
        onOpenChange={(ouvert) => {
          setDialogOuvert(ouvert);
          if (!ouvert) reinitialiserDialog();
        }}
      >
        <DialogContent className="max-h-[85vh] overflow-y-auto sm:max-w-lg" aria-label="Créer un nouvel export">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Package className="h-4 w-4 text-amber-600" aria-hidden="true" />
              Nouvel export
            </DialogTitle>
            <DialogDescription>
              Cochez le ou les OF déjà générés (3, 5, 8… par colis) : tout est
              récupéré automatiquement. Seul le numéro de colis est à saisir.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            {/* 1. Samedi de l'export — les deux prochains samedis */}
            <div className="space-y-1.5">
              <Label htmlFor="export-samedi">Samedi de l&apos;export</Label>
              <Select value={samedi} onValueChange={setSamedi}>
                <SelectTrigger id="export-samedi" aria-label="Choisir le samedi de l'export">
                  <SelectValue placeholder="Choisir le samedi…" />
                </SelectTrigger>
                <SelectContent>
                  {samedis.map((s) => (
                    <SelectItem key={s} value={s}>
                      {formaterSamedi(s)} — semaine {semaineIso(s)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* 2. OF déjà générés — recherche + sélection multiple (3, 5, 8…) */}
            <div className="space-y-1.5">
              <Label htmlFor="recherche-of">
                N° d&apos;OF (déjà générés)
                {ofsChoisis.length > 0 ? ` — ${ofsChoisis.length} sélectionné(s)` : ""}
              </Label>
              {ofs.length === 0 ? (
                <p
                  id="export-ofs"
                  className="rounded-md border border-dashed p-3 text-xs text-zinc-500 dark:text-zinc-400"
                >
                  Aucun OF généré pour l&apos;instant.
                </p>
              ) : (
                <>
                  {/* Recherche — retrouve un N° même avec des dizaines d'OF */}
                  <div className="relative">
                    <Search
                      className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-zinc-400"
                      aria-hidden="true"
                    />
                    <Input
                      id="recherche-of"
                      value={rechercheOf}
                      onChange={(e) => setRechercheOf(e.target.value)}
                      placeholder="Rechercher un N° d&apos;OF…"
                      inputMode="numeric"
                      className="h-9 pl-8"
                      autoComplete="off"
                      aria-label="Rechercher un N° d'OF déjà généré"
                    />
                  </div>

                  {/* OF sélectionnés — jetons retireables (sélection claire) */}
                  {ofsChoisis.length > 0 && (
                    <div
                      className="flex flex-wrap items-center gap-1.5 rounded-md border bg-zinc-50 p-2 dark:bg-zinc-900"
                      aria-label="OF sélectionnés pour cet export"
                    >
                      {ofsChoisis.map((of) => (
                        <span
                          key={of}
                          className="inline-flex items-center gap-1 rounded-full border border-amber-300 bg-amber-100 py-0.5 pl-2.5 pr-1 text-xs font-semibold text-amber-900 dark:border-amber-700 dark:bg-amber-950/60 dark:text-amber-200"
                        >
                          OF {of}
                          <button
                            type="button"
                            onClick={() => void basculerOf(of)}
                            className="rounded-full p-0.5 transition-colors hover:bg-amber-200 dark:hover:bg-amber-900"
                            aria-label={`Retirer l'OF ${of} de la sélection`}
                          >
                            <X className="h-3 w-3" aria-hidden="true" />
                          </button>
                        </span>
                      ))}
                      <button
                        type="button"
                        onClick={viderSelectionOfs}
                        className="ml-auto px-1 text-xs text-zinc-500 underline-offset-2 transition-colors hover:text-red-600 hover:underline dark:text-zinc-400"
                      >
                        Tout effacer
                      </button>
                    </div>
                  )}

                  {/* Liste des OF (filtrée par la recherche) */}
                  <div
                    className="max-h-56 overflow-y-auto rounded-md border"
                    role="group"
                    aria-label="Cocher un ou plusieurs OF déjà générés"
                  >
                    {ofsFiltres.length === 0 ? (
                      <p className="p-3 text-xs text-zinc-500 dark:text-zinc-400">
                        Aucun OF ne correspond à « {rechercheOf.trim()} ».
                      </p>
                    ) : (
                      <ul className="divide-y">
                        {ofsFiltres.map((o) => {
                          const actif = ofsChoisis.includes(o.of);
                          return (
                            <li key={o.of}>
                              <button
                                type="button"
                                onClick={() => void basculerOf(o.of)}
                                aria-pressed={actif}
                                className={`flex min-h-11 w-full items-center gap-2.5 px-3 py-2 text-left text-sm transition-colors ${
                                  actif
                                    ? "bg-amber-100 font-semibold text-amber-900 dark:bg-amber-950/60 dark:text-amber-200"
                                    : "hover:bg-zinc-50 dark:hover:bg-zinc-800/60"
                                }`}
                              >
                                <span
                                  aria-hidden="true"
                                  className={`flex h-4 w-4 shrink-0 items-center justify-center rounded border ${
                                    actif
                                      ? "border-amber-600 bg-amber-600 text-white"
                                      : "border-zinc-400 dark:border-zinc-600"
                                  }`}
                                >
                                  {actif && <Check className="h-3 w-3" />}
                                </span>
                                <span className="min-w-0 flex-1 truncate">
                                  OF {o.of}
                                  <span className="font-normal text-zinc-500 dark:text-zinc-400">
                                    {" "}— {o.nbEtiquettes} étiquette(s), {o.pieces} pièce(s)
                                  </span>
                                </span>
                              </button>
                            </li>
                          );
                        })}
                      </ul>
                    )}
                  </div>
                  <p className="text-xs text-zinc-500 dark:text-zinc-400">
                    Cochez TOUS les OF du colis : les articles, codes-barres,
                    quantités, couleurs et tailles sont récupérés
                    automatiquement — rien à ressaisir.
                  </p>
                </>
              )}
            </div>

            {/* Lignes automatiques des OF cochés */}
            {ofEnCours ? (
              <div className="flex items-center gap-2 rounded-md border p-3 text-sm text-zinc-500" aria-busy="true">
                <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
                Récupération des informations des OF…
              </div>
            ) : lignesAuto.length > 0 ? (
              <div className="space-y-1.5">
                <p className="text-sm font-semibold">
                  {ofsChoisis.length} OF sélectionné(s) — {lignesAuto.length} ligne(s) récupérée(s)
                </p>
                <div className="max-h-56 overflow-y-auto rounded-md border">
                  <table className="w-full text-xs">
                    <thead className="sticky top-0 bg-zinc-50 text-left text-zinc-500 dark:bg-zinc-800 dark:text-zinc-400">
                      <tr>
                        <th className="px-2 py-1.5 font-medium">OF</th>
                        <th className="px-2 py-1.5 font-medium">Modèle</th>
                        <th className="px-2 py-1.5 font-medium">Couleur</th>
                        <th className="px-2 py-1.5 font-medium">Taille</th>
                        <th className="px-2 py-1.5 font-medium">Codes</th>
                        <th className="px-2 py-1.5 text-right font-medium">Qté</th>
                      </tr>
                    </thead>
                    <tbody>
                      {lignesAuto.map((l, i) => (
                        <tr key={i} className="border-t dark:border-zinc-800">
                          <td className="px-2 py-1.5 font-mono">{l.of || "—"}</td>
                          <td className="px-2 py-1.5">{l.modele}</td>
                          <td className="px-2 py-1.5">{l.couleur}</td>
                          <td className="px-2 py-1.5">{l.taille}</td>
                          <td className="px-2 py-1.5">
                            <span
                              className="cursor-help underline decoration-dotted underline-offset-2"
                              title={l.codes && l.codes.length > 0 ? l.codes.join(", ") : undefined}
                            >
                              {l.codes ? l.codes.length : 0} code(s)
                            </span>
                          </td>
                          <td className="px-2 py-1.5 text-right font-semibold">{l.quantite}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            ) : null}

            {/* Lignes manuelles ajoutées */}
            {lignesManuelles.length > 0 ? (
              <div className="space-y-1.5">
                <p className="text-sm font-semibold">
                  Lignes ajoutées à la main ({lignesManuelles.length})
                </p>
                <ul className="max-h-40 space-y-1 overflow-y-auto" aria-label="Lignes manuelles">
                  {lignesManuelles.map((l, i) => (
                    <li
                      key={i}
                      className="flex items-center gap-2 rounded-md border bg-zinc-50 px-2 py-1.5 text-xs dark:bg-zinc-800/60"
                    >
                      <span className="min-w-0 flex-1 truncate">
                        {l.article}
                        {l.couleur ? ` — ${l.couleur}` : ""}
                        {l.taille ? ` — ${l.taille}` : ""}
                        {l.of ? ` (OF ${l.of})` : ""}
                      </span>
                      <span className="font-semibold">{l.quantite}</span>
                      <button
                        type="button"
                        onClick={() =>
                          setLignesManuelles((liste) => liste.filter((_, j) => j !== i))
                        }
                        className="rounded p-1 text-zinc-400 hover:bg-red-50 hover:text-red-600 dark:hover:bg-red-950/40"
                        aria-label={`Retirer la ligne ${l.article}`}
                      >
                        <X className="h-3.5 w-3.5" aria-hidden="true" />
                      </button>
                    </li>
                  ))}
                </ul>
              </div>
            ) : null}

            {/* « Ajouter une ligne » — possibility secondaire */}
            {ajoutOuvert ? (
              <div className="space-y-2 rounded-md border border-dashed p-3">
                <p className="text-xs font-medium text-zinc-500 dark:text-zinc-400">
                  Ligne hors OF (saisie manuelle)
                </p>
                <div className="grid grid-cols-2 gap-2">
                  <div className="col-span-2 space-y-1">
                    <Label htmlFor="export-m-article" className="text-xs">
                      Article / référence
                    </Label>
                    <Input
                      id="export-m-article"
                      value={mArticle}
                      onChange={(e) => setMArticle(e.target.value)}
                      placeholder="ex. SFAX ML"
                      className="h-8"
                    />
                  </div>
                  <div className="space-y-1">
                    <Label htmlFor="export-m-couleur" className="text-xs">
                      Couleur (option)
                    </Label>
                    <Input
                      id="export-m-couleur"
                      value={mCouleur}
                      onChange={(e) => setMCouleur(e.target.value)}
                      placeholder="ex. Blanc"
                      className="h-8"
                    />
                  </div>
                  <div className="space-y-1">
                    <Label htmlFor="export-m-taille" className="text-xs">
                      Taille (option)
                    </Label>
                    <Input
                      id="export-m-taille"
                      value={mTaille}
                      onChange={(e) => setMTaille(e.target.value)}
                      placeholder="ex. T40"
                      className="h-8"
                    />
                  </div>
                  <div className="space-y-1">
                    <Label htmlFor="export-m-quantite" className="text-xs">
                      Quantité (1 à {QUANTITE_MAX})
                    </Label>
                    <Input
                      id="export-m-quantite"
                      type="number"
                      min={1}
                      max={QUANTITE_MAX}
                      value={mQuantite}
                      onChange={(e) => setMQuantite(e.target.value)}
                      className="h-8"
                    />
                  </div>
                  <div className="flex items-end gap-2">
                    <Button type="button" size="sm" className="h-8 flex-1" onClick={ajouterLigneManuelle}>
                      Ajouter
                    </Button>
                    <Button
                      type="button"
                      size="sm"
                      variant="ghost"
                      className="h-8"
                      onClick={() => setAjoutOuvert(false)}
                    >
                      Annuler
                    </Button>
                  </div>
                </div>
              </div>
            ) : (
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => setAjoutOuvert(true)}
                className="text-xs"
              >
                <Plus className="h-3.5 w-3.5" aria-hidden="true" />
                Ajouter une ligne
              </Button>
            )}

            {/* 3. Numéro de colis — la seule information nouvelle à saisir */}
            <div className="space-y-1.5">
              <Label htmlFor="export-colis">Numéro de colis</Label>
              <Input
                id="export-colis"
                value={numeroColis}
                onChange={(e) => setNumeroColis(e.target.value)}
                placeholder="ex. 12345"
                maxLength={40}
              />
            </div>

            {/* Récapitulatif */}
            <p className="text-xs text-zinc-500 dark:text-zinc-400">
              Total : {nbLignesTotal} ligne(s) — {quantiteTotale} pièce(s)
              {samedi ? ` — départ le ${formaterSamedi(samedi)}` : ""}
            </p>
          </div>

          <DialogFooter className="gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => setDialogOuvert(false)}
              disabled={creationEnCours}
            >
              Annuler
            </Button>
            <Button type="button" onClick={() => void creerExport()} disabled={!peutCreer}>
              {creationEnCours ? (
                <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
              ) : (
                <Send className="h-4 w-4" aria-hidden="true" />
              )}
              Créer l&apos;export
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Bandeau d'identité du site expéditeur (façonnier) */}
      {compte?.role === "faconnier" && (
        <p className="flex items-center gap-2 text-xs text-zinc-400 dark:text-zinc-500">
          <Factory className="h-3.5 w-3.5" aria-hidden="true" />
          Exports enregistrés pour {compte.siteLabel} — visibles par le stock à
          la réception.
        </p>
      )}
    </div>
  );
}
