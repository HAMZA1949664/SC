"use client";

/**
 * Panneau « Comptes & accès » — réservé au service achats (rôle « achats »,
 * ou l'ancien rôle « france »).
 *
 * Liste tous les comptes de cloud.config.json regroupés par société et
 * permet de CHANGER LE CODE D'ACCÈS (mot de passe) de chacun, directement
 * depuis le site : l'API réécrit cloud.config.json côté serveur (écriture
 * atomique) — le code n'est jamais envoyé au navigateur et n'apparaît
 * qu'au moment de la saisie.
 *
 * Alternative manuelle : éditer cloud.config.json à la racine du projet
 * (champ « code » du compte concerné) — la configuration est relue toutes
 * les 5 secondes, aucun redémarrage nécessaire.
 */

import { useCallback, useEffect, useMemo, useState } from "react";
import {
  Boxes,
  Building2,
  Factory,
  KeyRound,
  Loader2,
  Lock,
  ShoppingCart,
  UserCog,
} from "lucide-react";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { useCompte, peutGererComptes } from "@/components/compte-garde";

/** Compte public tel que renvoyé par /api/auth/compte (sans code secret). */
interface CompteListe {
  identifiant: string;
  nom: string;
  role: "stock" | "achats" | "faconnier" | "france";
  siteId: string;
  siteLabel: string;
}

/** Libellé + icône de chaque rôle (affichage). */
function infosRole(role: CompteListe["role"]): { libelle: string; classe: string } {
  switch (role) {
    case "stock":
      return {
        libelle: "Stock — réception & étiquettes",
        classe: "border-sky-600/50 text-sky-700 dark:text-sky-400",
      };
    case "achats":
      return {
        libelle: "Achats — accès complet",
        classe: "border-emerald-600/50 text-emerald-700 dark:text-emerald-400",
      };
    case "france":
      return {
        libelle: "Accès complet (ancien)",
        classe: "border-emerald-600/50 text-emerald-700 dark:text-emerald-400",
      };
    default:
      return {
        libelle: "Façonnier — étiquettes",
        classe: "border-amber-600/50 text-amber-700 dark:text-amber-400",
      };
  }
}

export function PanneauComptes() {
  const { compte } = useCompte();
  const { toast } = useToast();

  const [ouvert, setOuvert] = useState(false);
  const [comptes, setComptes] = useState<CompteListe[]>([]);
  const [charge, setCharge] = useState(false);
  const [erreurChargement, setErreurChargement] = useState<string | null>(null);

  // Édition du code d'un compte
  const [cible, setCible] = useState<CompteListe | null>(null);
  const [nouveauCode, setNouveauCode] = useState("");
  const [confirmation, setConfirmation] = useState("");
  const [enregistrement, setEnregistrement] = useState(false);

  /** L'utilisateur courant peut-il ouvrir ce panneau ? */
  const autorise = compte ? peutGererComptes(compte.role) : false;

  const chargerComptes = useCallback(async () => {
    setErreurChargement(null);
    try {
      const res = await fetch("/api/auth/compte", { cache: "no-store" });
      const corps = await res.json().catch(() => null);
      if (!res.ok || !corps || !Array.isArray(corps.comptes)) {
        setErreurChargement("Lecture des comptes impossible.");
        return;
      }
      setComptes(corps.comptes as CompteListe[]);
    } catch {
      setErreurChargement("Connexion au serveur impossible.");
    } finally {
      setCharge(true);
    }
  }, []);

  useEffect(() => {
    if (ouvert) void chargerComptes();
  }, [ouvert, chargerComptes]);

  /** Comptes regroupés par société (ordre : Clément, puis les autres). */
  const groupes = useMemo(() => {
    const map = new Map<string, CompteListe[]>();
    for (const c of comptes) {
      const liste = map.get(c.siteLabel) ?? [];
      liste.push(c);
      map.set(c.siteLabel, liste);
    }
    return [...map.entries()].sort(([a], [b]) => {
      if (a.startsWith("France")) return -1;
      if (b.startsWith("France")) return 1;
      return a.localeCompare(b, "fr");
    });
  }, [comptes]);

  function ouvrirEdition(c: CompteListe) {
    setCible(c);
    setNouveauCode("");
    setConfirmation("");
  }

  async function enregistrerCode() {
    if (!cible) return;
    if (nouveauCode.trim().length < 4) {
      toast({
        title: "Code trop court",
        description: "4 caractères minimum.",
        variant: "destructive",
      });
      return;
    }
    if (nouveauCode !== confirmation) {
      toast({
        title: "Les deux saisies ne correspondent pas",
        description: "Vérifiez le nouveau code et sa confirmation.",
        variant: "destructive",
      });
      return;
    }
    setEnregistrement(true);
    try {
      const res = await fetch("/api/auth/compte", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "changer-code",
          identifiant: cible.identifiant,
          nouveauCode,
        }),
      });
      const corps = await res.json().catch(() => null);
      if (!res.ok) {
        toast({
          title: "Changement impossible",
          description:
            (corps && typeof corps.error === "string" && corps.error) ||
            "Réessayez.",
          variant: "destructive",
        });
        return;
      }
      toast({
        title: "Code mis à jour",
        description: `« ${cible.nom} » se connecte désormais avec le nouveau code (effectif en ~5 s).`,
      });
      setCible(null);
    } catch {
      toast({
        title: "Erreur réseau",
        description: "Connexion au serveur impossible. Réessayez.",
        variant: "destructive",
      });
    } finally {
      setEnregistrement(false);
    }
  }

  if (!autorise) return null;

  return (
    <Dialog open={ouvert} onOpenChange={setOuvert}>
      <DialogTrigger asChild>
        <Button
          variant="ghost"
          size="icon"
          aria-label="Comptes et accès : gérer les codes de connexion"
          className="h-9 w-9 text-zinc-300 hover:bg-zinc-800 hover:text-white"
        >
          <KeyRound className="h-4 w-4" aria-hidden="true" />
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-xl" aria-label="Comptes et accès">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <UserCog className="h-5 w-5 text-amber-600" aria-hidden="true" />
            Comptes &amp; accès
          </DialogTitle>
          <DialogDescription>
            Changez le code d&apos;accès (mot de passe) de chaque compte : la
            modification est écrite dans cloud.config.json sur le serveur et
            prend effet en ~5 secondes, sans redémarrage.
          </DialogDescription>
        </DialogHeader>

        {!charge ? (
          <p className="flex items-center justify-center gap-2 py-8 text-sm text-muted-foreground">
            <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
            Lecture des comptes…
          </p>
        ) : erreurChargement ? (
          <p
            role="alert"
            className="rounded-md border border-red-300 bg-red-50 px-3 py-2 text-sm text-red-800 dark:border-red-500/40 dark:bg-red-950/40 dark:text-red-300"
          >
            {erreurChargement}
          </p>
        ) : (
          <div className="max-h-[26rem] space-y-4 overflow-y-auto pr-1">
            {groupes.map(([site, liste]) => (
              <section key={site} aria-label={site}>
                <h3 className="mb-2 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                  <Building2 className="h-3.5 w-3.5" aria-hidden="true" />
                  {site}
                </h3>
                <ul className="space-y-1.5">
                  {liste.map((c) => {
                    const role = infosRole(c.role);
                    return (
                      <li
                        key={c.identifiant}
                        className="flex flex-wrap items-center gap-2 rounded-lg border bg-white px-3 py-2 dark:bg-zinc-950"
                      >
                        <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-zinc-100 text-zinc-500 dark:bg-zinc-800 dark:text-zinc-400">
                          {c.role === "stock" ? (
                            <Boxes className="h-4 w-4" aria-hidden="true" />
                          ) : c.role === "achats" ? (
                            <ShoppingCart className="h-4 w-4" aria-hidden="true" />
                          ) : c.role === "france" ? (
                            <Building2 className="h-4 w-4" aria-hidden="true" />
                          ) : (
                            <Factory className="h-4 w-4" aria-hidden="true" />
                          )}
                        </span>
                        <span className="min-w-0 flex-1">
                          <span className="block truncate text-sm font-semibold">
                            {c.nom}
                          </span>
                          <span className="block truncate font-mono text-[11px] text-muted-foreground">
                            {c.identifiant}
                          </span>
                        </span>
                        <Badge
                          variant="outline"
                          className={`max-w-full truncate text-[10px] leading-tight ${role.classe}`}
                        >
                          {role.libelle}
                        </Badge>
                        <Button
                          variant="outline"
                          size="sm"
                          className="h-8 shrink-0 px-2 text-xs"
                          onClick={() => ouvrirEdition(c)}
                          aria-label={`Changer le code d'accès de ${c.nom}`}
                        >
                          <KeyRound className="mr-1 h-3.5 w-3.5" aria-hidden="true" />
                          Code
                        </Button>
                      </li>
                    );
                  })}
                </ul>
              </section>
            ))}
          </div>
        )}

        <p className="text-[11px] leading-relaxed text-muted-foreground">
          Vous pouvez aussi modifier les comptes directement dans{" "}
          <code className="rounded bg-zinc-100 px-1 font-mono text-[10px] dark:bg-zinc-800">
            cloud.config.json
          </code>{" "}
          à la racine du projet (ajout, suppression, rôles, sites) — la
          configuration est relue automatiquement.
        </p>

        {/* ---- Sous-dialogue : changement du code d'accès ---- */}
        <Dialog open={cible !== null} onOpenChange={(o) => !o && setCible(null)}>
          <DialogContent className="sm:max-w-md" aria-label="Changer le code d'accès">
            <DialogHeader>
              <DialogTitle>Changer le code de « {cible?.nom} »</DialogTitle>
              <DialogDescription>
                Le nouveau code remplace immédiatement l&apos;ancien (compte{" "}
                <span className="font-mono text-xs">{cible?.identifiant}</span>).
                Prévenez la personne : elle se reconnecte avec le nouveau code.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-3">
              <div className="space-y-1.5">
                <Label htmlFor="nouveau-code">Nouveau code d&apos;accès</Label>
                <Input
                  id="nouveau-code"
                  type="text"
                  value={nouveauCode}
                  onChange={(e) => setNouveauCode(e.target.value)}
                  placeholder="4 caractères minimum"
                  autoComplete="off"
                  autoFocus
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="confirmation-code">Confirmer le nouveau code</Label>
                <Input
                  id="confirmation-code"
                  type="text"
                  value={confirmation}
                  onChange={(e) => setConfirmation(e.target.value)}
                  placeholder="Ressaisissez le même code"
                  autoComplete="off"
                />
              </div>
            </div>
            <DialogFooter className="gap-2">
              <Button variant="outline" onClick={() => setCible(null)} disabled={enregistrement}>
                Annuler
              </Button>
              <Button
                onClick={() => void enregistrerCode()}
                disabled={enregistrement || nouveauCode.trim().length < 4}
                className="bg-amber-600 font-semibold text-white hover:bg-amber-700"
              >
                {enregistrement ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" aria-hidden="true" />
                ) : (
                  <Lock className="mr-2 h-4 w-4" aria-hidden="true" />
                )}
                Enregistrer le nouveau code
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </DialogContent>
    </Dialog>
  );
}
