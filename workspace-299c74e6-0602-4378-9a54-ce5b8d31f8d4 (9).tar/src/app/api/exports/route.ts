import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { lireCompteRequete } from "@/lib/cloud/session";
import { lireConfigFichier } from "@/lib/cloud/config-fichier";
import { empilerSync } from "@/lib/cloud/queue";
import { MAX_LIGNES_RECEPTION } from "@/lib/receptions";
import { attribuerOfsSite, ofsAutorisesPourSite } from "@/lib/ofs-sites";
import { envoyerMailColisageExport } from "@/lib/mail";
import {
  type CorpsCreationExport,
  type ExportListe,
  type LigneExport,
  type MetaExport,
  type OfDisponible,
  encoderMetaExport,
  estSamedi,
  lireMetaExport,
  nomCourtSite,
  semaineIso,
} from "@/lib/exports";

export const dynamic = "force-dynamic";

interface ErreurApi {
  error: string;
}

/** Plafonds de saisie. */
const LIMITE_TITRE = 120;
const LIMITE_COLIS = 40;
const LIMITE_ARTICLE = 60;
const MAX_LIGNES_MANUELLES = 200;
/** Nombre maximal d'OF regroupés dans un même export (3, 5, 8… observés). */
const MAX_OFS_PAR_EXPORT = 50;
/** Aperçu de codes-barres conservé par ligne (info automatique de l'OF). */
const MAX_CODES_APERCU = 50;

/** Compte courant, ou null si l'authentification est désactivée. */
async function compteOuAuthInactif() {
  const cfg = await lireConfigFichier();
  if (cfg.comptes.length === 0) return { compte: null, authActive: false };
  const compte = await lireCompteRequete();
  if (!compte) return { compte: null, authActive: true };
  return { compte, authActive: true };
}

/** Garde de LECTURE : tout compte connecté peut consulter les exports. */
async function gardeLecture(): Promise<string | null> {
  const { compte, authActive } = await compteOuAuthInactif();
  if (authActive && !compte) {
    return "Connexion requise : identifiez-vous pour consulter les exports.";
  }
  return null;
}

/** Garde d'ÉCRITURE : le façonnier (et le service achats) créent les exports. */
async function gardeEcriture(): Promise<string | null> {
  const { compte, authActive } = await compteOuAuthInactif();
  if (authActive && !compte) {
    return "Connexion requise : identifiez-vous pour créer un export.";
  }
  if (
    compte &&
    compte.role !== "faconnier" &&
    compte.role !== "achats" &&
    compte.role !== "france"
  ) {
    return "Création d'export réservée aux comptes façonnier et achats.";
  }
  return null;
}

/**
 * Isolation des usines (demande Clément Design) : un façonnier ne peut voir
 * ni exporter que « ses » OF — ceux générés par son site. Les comptes France
 * (achats) voient tous les OF. Retourne le message d'erreur FR si un OF de la
 * liste est interdit au compte courant, sinon null.
 */
async function refusOfsInterdits(listeOfs: string[]): Promise<string | null> {
  const { compte, authActive } = await compteOuAuthInactif();
  if (authActive && compte?.role === "faconnier") {
    const autorises = await ofsAutorisesPourSite(listeOfs, compte.siteId);
    if (autorises.length !== listeOfs.length) {
      return "Un ou plusieurs OF ne sont pas disponibles pour votre site.";
    }
  }
  return null;
}

/**
 * Regroupe les étiquettes d'un ou plusieurs OF en lignes d'export
 * (OF → modèle → couleur → taille → manche), quantités sommées, avec un
 * aperçu des codes-barres par ligne — l'utilisateur ne saisit RIEN.
 */
async function lignesDepuisOfs(
  ofs: string[]
): Promise<{ lignes: LigneExport[]; quantiteTotale: number; nbEtiquettes: number }> {
  const etiquettes = await db.labelRecord.findMany({
    where: { of: { in: ofs } },
    select: {
      codeBarre: true,
      of: true,
      modele: true,
      couleur: true,
      couleurCode: true,
      taille: true,
      manche: true,
      quantite: true,
    },
    orderBy: { createdAt: "asc" },
  });

  interface Agregat extends LigneExport {
    codesVus: Set<string>;
  }
  const agregats = new Map<string, Agregat>();
  for (const e of etiquettes) {
    const cle = `${e.of}|${e.modele}|${e.couleur}|${e.taille}|${e.manche}`;
    let a = agregats.get(cle);
    if (!a) {
      a = {
        of: e.of,
        modele: e.modele,
        couleur: e.couleur || "Non résolue",
        couleurCode: e.couleurCode || "",
        taille: e.taille || "?",
        manche: e.manche || "",
        quantite: 0,
        codes: [],
        codesVus: new Set<string>(),
      };
      agregats.set(cle, a);
    }
    a.quantite += e.quantite;
    if (!a.codesVus.has(e.codeBarre)) {
      a.codesVus.add(e.codeBarre);
      if (a.codes!.length < MAX_CODES_APERCU) a.codes!.push(e.codeBarre);
    }
  }

  const lignes: LigneExport[] = [...agregats.values()].map((a) => ({
    of: a.of,
    modele: a.modele,
    couleur: a.couleur,
    couleurCode: a.couleurCode,
    taille: a.taille,
    manche: a.manche,
    quantite: a.quantite,
    codes: a.codes,
  }));
  lignes.sort(
    (x, y) =>
      x.of.localeCompare(y.of, "fr", { numeric: true }) ||
      x.modele.localeCompare(y.modele, "fr") ||
      x.taille.localeCompare(y.taille, "fr", { numeric: true })
  );
  return {
    lignes,
    quantiteTotale: lignes.reduce((s, l) => s + l.quantite, 0),
    nbEtiquettes: etiquettes.length,
  };
}

/**
 * GET /api/exports
 *  - sans paramètre : liste des exports + OF déjà générés (pour la sélection) ;
 *  - ?of=078600 ou ?of=078600,078601,078602 : lignes automatiques de ces OF
 *    (récupération instantanée des articles, codes-barres, quantités,
 *    couleurs, tailles — rien à ressaisir).
 */
export async function GET(req: Request) {
  const refus = await gardeLecture();
  if (refus) return NextResponse.json({ error: refus }, { status: 403 });

  try {
    const { compte, authActive } = await compteOuAuthInactif();
    const url = new URL(req.url);
    const ofDemande = (url.searchParams.get("of") ?? "").trim();

    // --- Détail d'un ou plusieurs OF (auto-remplissage du nouvel export) ---
    if (ofDemande) {
      const listeOfs = [
        ...new Set(
          ofDemande
            .split(",")
            .map((o) => o.trim())
            .filter((o) => o.length > 0)
        ),
      ];
      if (
        listeOfs.length === 0 ||
        listeOfs.length > MAX_OFS_PAR_EXPORT ||
        listeOfs.some((o) => !/^\d{1,20}$/.test(o))
      ) {
        return NextResponse.json(
          { error: "Numéro d'OF invalide." },
          { status: 400 }
        );
      }
      // Isolation des usines : un façonnier ne consulte que ses OF.
      const refusOf = await refusOfsInterdits(listeOfs);
      if (refusOf) {
        return NextResponse.json({ error: refusOf }, { status: 403 });
      }
      const { lignes, quantiteTotale, nbEtiquettes } = await lignesDepuisOfs(
        listeOfs
      );
      if (lignes.length === 0) {
        return NextResponse.json(
          {
            error:
              "Aucune étiquette générée ne porte ces OF. Générez d'abord les étiquettes, ou utilisez « Ajouter une ligne ».",
          },
          { status: 404 }
        );
      }
      return NextResponse.json(
        { of: listeOfs.join(","), lignes, quantiteTotale, nbEtiquettes },
        { headers: { "Cache-Control": "no-store" } }
      );
    }

    // --- Liste des exports enregistrés ------------------------------------
    const receptions = await db.reception.findMany({
      where: { note: { startsWith: "EXPORT|" } },
      orderBy: { createdAt: "desc" },
      include: {
        lignes: {
          select: {
            of: true,
            modele: true,
            couleur: true,
            couleurCode: true,
            taille: true,
            manche: true,
            attendu: true,
          },
        },
      },
    });

    const exports: ExportListe[] = [];
    for (const r of receptions) {
      const meta = lireMetaExport(r.note);
      if (!meta) continue;
      // Un façonnier ne voit que ses propres exports (séparation des usines).
      if (
        authActive &&
        compte?.role === "faconnier" &&
        meta.siteId !== compte.siteId
      ) {
        continue;
      }
      const lignes: LigneExport[] = r.lignes.map((l) => ({
        of: l.of,
        modele: l.modele,
        couleur: l.couleur,
        couleurCode: l.couleurCode,
        taille: l.taille,
        manche: l.manche,
        quantite: l.attendu,
      }));
      exports.push({
        id: r.id,
        titre: r.titre,
        statut: r.statut,
        dateExport: meta.dateExport,
        numeroColis: meta.numeroColis,
        siteId: meta.siteId,
        siteLabel: meta.siteLabel,
        creeParNom: meta.creeParNom,
        creeAt: r.createdAt.toISOString(),
        lignes,
        quantiteTotale: lignes.reduce((s, l) => s + l.quantite, 0),
      });
    }

    // --- OF déjà générés (liste de sélection du nouvel export) -------------
    const groupes = await db.labelRecord.groupBy({
      by: ["of"],
      where: { of: { not: "" } },
      _count: { of: true },
      _sum: { quantite: true },
      _max: { createdAt: true },
    });
    const ofs: OfDisponible[] = groupes
      .map((g) => ({
        of: g.of,
        nbEtiquettes: g._count.of,
        pieces: g._sum.quantite ?? 0,
        dernierAt: (g._max.createdAt ?? new Date(0)).toISOString(),
      }))
      // Seuls les OF numériques sont proposés (cohérent avec la création).
      .filter((o) => /^\d{1,20}$/.test(o.of))
      .sort(
        (a, b) =>
          b.dernierAt.localeCompare(a.dernierAt) ||
          a.of.localeCompare(b.of, "fr", { numeric: true })
      )
      .slice(0, 200);

    // Isolation des usines : un façonnier ne voit que les OF générés par son
    // site (jamais ceux des autres usines — demande Clément Design).
    let ofsVisibles = ofs;
    if (authActive && compte?.role === "faconnier") {
      const autorises = new Set(
        await ofsAutorisesPourSite(
          ofs.map((o) => o.of),
          compte.siteId
        )
      );
      ofsVisibles = ofs.filter((o) => autorises.has(o.of));
    }

    return NextResponse.json(
      { exports, ofs: ofsVisibles },
      { headers: { "Cache-Control": "no-store" } }
    );
  } catch (error) {
    console.error("Lecture des exports impossible :", error);
    return NextResponse.json(
      { error: "Lecture des exports impossible (erreur serveur)." },
      { status: 500 }
    );
  }
}

/**
 * POST /api/exports — crée un export (départ du samedi) :
 *  - `of` fourni → toutes les lignes de l'OF sont récupérées automatiquement ;
 *  - `lignesManuelles` → lignes ajoutées via « Ajouter une ligne » ;
 *  - `numeroColis` → la seule information nouvelle de colisage.
 * Enregistrement dans les tables réceptions existantes (aucune modification
 * de la base), puis miroir cloud identique aux réceptions.
 */
export async function POST(req: Request) {
  const refus = await gardeEcriture();
  if (refus) return NextResponse.json({ error: refus }, { status: 403 });

  let corps: CorpsCreationExport;
  try {
    corps = (await req.json()) as CorpsCreationExport;
  } catch {
    const reponse: ErreurApi = { error: "Corps de requête JSON invalide." };
    return NextResponse.json(reponse, { status: 400 });
  }

  const { compte, authActive } = await compteOuAuthInactif();
  void authActive;
  const siteId = compte?.siteId ?? "france-hq";
  const siteLabel = compte?.siteLabel ?? "France — Clément Design";

  // --- Validations ---------------------------------------------------------
  const dateExport = (corps.dateExport ?? "").trim();
  if (!estSamedi(dateExport)) {
    return NextResponse.json(
      { error: "La date d'export doit être un samedi (AAAA-MM-JJ)." },
      { status: 400 }
    );
  }
  const numeroColis = (corps.numeroColis ?? "").trim();
  if (numeroColis.length === 0 || numeroColis.length > LIMITE_COLIS) {
    return NextResponse.json(
      { error: `Numéro de colis requis (1 à ${LIMITE_COLIS} caractères).` },
      { status: 400 }
    );
  }

  const ofDemande = (corps.of ?? "").trim();
  if (ofDemande && !/^\d{1,20}$/.test(ofDemande)) {
    return NextResponse.json(
      { error: "Numéro d'OF invalide." },
      { status: 400 }
    );
  }

  // Un ou plusieurs OF (parfois 3, 5, 8 OF par export) — « of » seul gardé
  // pour compatibilité, fusionné sans doublons.
  const listeOfs = [
    ...new Set(
      [
        ...(Array.isArray(corps.ofs)
          ? corps.ofs.map((o) => String(o ?? "").trim())
          : []),
        ...(ofDemande ? [ofDemande] : []),
      ].filter((o) => o.length > 0)
    ),
  ];
  if (listeOfs.some((o) => !/^\d{1,20}$/.test(o))) {
    return NextResponse.json(
      { error: "Numéro d'OF invalide." },
      { status: 400 }
    );
  }
  if (listeOfs.length > MAX_OFS_PAR_EXPORT) {
    return NextResponse.json(
      { error: `Trop d'OF dans un même export (max ${MAX_OFS_PAR_EXPORT}).` },
      { status: 400 }
    );
  }

  // Isolation des usines : un façonnier n'exporte que ses propres OF.
  const refusOf = await refusOfsInterdits(listeOfs);
  if (refusOf) {
    return NextResponse.json({ error: refusOf }, { status: 403 });
  }

  const manuelles = Array.isArray(corps.lignesManuelles)
    ? corps.lignesManuelles
    : [];
  if (manuelles.length > MAX_LIGNES_MANUELLES) {
    return NextResponse.json(
      { error: `Trop de lignes manuelles (max ${MAX_LIGNES_MANUELLES}).` },
      { status: 400 }
    );
  }
  const lignesManuelles: LigneExport[] = [];
  for (const m of manuelles) {
    const article = (m.article ?? "").trim();
    if (article.length === 0 || article.length > LIMITE_ARTICLE) {
      return NextResponse.json(
        {
          error: `Ligne manuelle : article/référence requis (1 à ${LIMITE_ARTICLE} caractères).`,
        },
        { status: 400 }
      );
    }
    const quantite = Math.trunc(Number(m.quantite));
    if (!Number.isFinite(quantite) || quantite < 1 || quantite > 999) {
      return NextResponse.json(
        {
          error: `Ligne manuelle « ${article.slice(0, 20)} » : quantité entre 1 et 999.`,
        },
        { status: 400 }
      );
    }
    const ofManuel = (m.of ?? "").trim();
    if (ofManuel && !/^\d{1,20}$/.test(ofManuel)) {
      return NextResponse.json(
        { error: `Ligne manuelle « ${article.slice(0, 20)} » : OF invalide.` },
        { status: 400 }
      );
    }
    lignesManuelles.push({
      of: ofManuel,
      modele: article,
      couleur: (m.couleur ?? "").trim() || "Non précisée",
      couleurCode: "",
      taille: (m.taille ?? "").trim() || "?",
      manche: (m.manche ?? "").trim() || "",
      quantite,
    });
  }

  try {
    // --- Lignes automatiques des OF (rien à ressaisir) --------------------
    let lignesAuto: LigneExport[] = [];
    if (listeOfs.length > 0) {
      const r = await lignesDepuisOfs(listeOfs);
      if (r.lignes.length === 0) {
        return NextResponse.json(
          {
            error:
              "Aucune étiquette générée ne porte ces OF. Générez d'abord les étiquettes, ou utilisez « Ajouter une ligne ».",
          },
          { status: 422 }
        );
      }
      lignesAuto = r.lignes;
    }

    const lignes = [...lignesAuto, ...lignesManuelles];
    if (lignes.length === 0) {
      return NextResponse.json(
        {
          error:
            "Export vide : choisissez un OF déjà généré ou ajoutez au moins une ligne.",
        },
        { status: 422 }
      );
    }
    if (lignes.length > MAX_LIGNES_RECEPTION) {
      return NextResponse.json(
        {
          error: `Trop de lignes (${lignes.length}). Maximum : ${MAX_LIGNES_RECEPTION.toLocaleString("fr-FR")}.`,
        },
        { status: 422 }
      );
    }

    // --- Titre (auto : « Export semaine N — {site} ») -----------------------
    const titreSaisi = (corps.titre ?? "").trim();
    const titre =
      titreSaisi.length > 0 && titreSaisi.length <= LIMITE_TITRE
        ? titreSaisi
        : `Export semaine ${semaineIso(dateExport)} — ${nomCourtSite(siteLabel)}`;

    // --- Métadonnée export (champ note, aucun changement de base) ----------
    const meta: MetaExport = {
      v: 1,
      dateExport,
      numeroColis,
      siteId,
      siteLabel,
      creePar: compte?.identifiant ?? "",
      creeParNom: compte?.nom ?? "",
      ofs: listeOfs,
    };

    // Identifiants explicites : repris comme local_id cloud (idempotence).
    const lignesDb = lignes.map((l) => ({
      id: crypto.randomUUID(),
      of: l.of,
      modele: l.modele,
      couleur: l.couleur,
      couleurCode: l.couleurCode,
      taille: l.taille,
      manche: l.manche,
      quantite: l.quantite,
    }));
    const quantiteTotale = lignes.reduce((s, l) => s + l.quantite, 0);

    const creee = await db.reception.create({
      data: {
        titre,
        note: encoderMetaExport(meta),
        lignes: {
          create: lignesDb.map((l) => ({
            id: l.id,
            of: l.of,
            modele: l.modele,
            couleur: l.couleur,
            couleurCode: l.couleurCode,
            taille: l.taille,
            manche: l.manche,
            attendu: l.quantite,
          })),
        },
      },
      select: { id: true },
    });

    // --- Miroir cloud (identique aux réceptions) ----------------------------
    const creeAt = new Date().toISOString();
    void empilerSync("receptions", [
      {
        local_id: creee.id,
        titre,
        statut: "ouverte",
        note: encoderMetaExport(meta),
        cree_at: creeAt,
      },
    ]);
    void empilerSync(
      "reception_lines",
      lignesDb.map((l) => ({
        local_id: l.id,
        reception_local_id: creee.id,
        of: l.of,
        modele: l.modele,
        couleur: l.couleur,
        couleur_code: l.couleurCode,
        taille: l.taille,
        manche: l.manche,
        attendu: l.quantite,
      }))
    );

    // Les OF exportés sont rattachés au site expéditeur (isolation des
    // usines) — jamais bloquant.
    if (listeOfs.length > 0) void attribuerOfsSite(listeOfs, siteId);

    // Mail de colisage aux achats (demande Clément Design) : à chaque export
    // créé par un façonnier, envoi du tableau (N° OF, article, manche,
    // couleur, taille) + n° de colis à _achat@clementdesign.com. Jamais
    // bloquant — l'export est déjà créé et la réponse part.
    if (compte?.role === "faconnier") {
      void envoyerMailColisageExport({
        titre,
        dateExport,
        numeroColis,
        siteId,
        siteLabel,
        creeParNom: compte.nom ?? "",
        lignes,
        quantiteTotale,
      });
    }

    return NextResponse.json(
      { id: creee.id, titre, lignes: lignes.length, quantiteTotale },
      { status: 201 }
    );
  } catch (error) {
    console.error("Création de l'export impossible :", error);
    return NextResponse.json(
      { error: "Création de l'export impossible (erreur serveur)." },
      { status: 500 }
    );
  }
}
