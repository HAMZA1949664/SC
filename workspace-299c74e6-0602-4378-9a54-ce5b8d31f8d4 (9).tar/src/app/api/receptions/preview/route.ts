import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { clauseSource } from "@/lib/receptions-server";
import { exigerReception } from "@/lib/cloud/session";
import type { SourceReception } from "@/lib/receptions";

export const dynamic = "force-dynamic";

/**
 * POST /api/receptions/preview — aperçu AVANT création.
 *
 * Corps : { source } (même forme que POST /api/receptions, sans titre).
 * Retourne le nombre d'étiquettes correspondant à la source, le nombre de
 * lignes attendues (regroupement OF → modèle → couleur → taille) et la
 * quantité totale — SANS écrire quoi que ce soit en base.
 *
 * Utilisé par le dialogue « Nouvelle réception prévue » pour afficher en
 * direct ce que la source va produire : si le compteur est à zéro, le
 * bouton de création est désactivé et l'opérateur voit immédiatement
 * pourquoi (période vide, OF inconnu…), au lieu de découvrir un message
 * d'erreur après validation.
 */
export async function POST(req: Request) {
  // Auth active : l'aperçu de réception est réservé au compte France.
  const garde = await exigerReception();
  if (garde) return NextResponse.json({ error: garde }, { status: 403 });

  let corps: { source?: SourceReception };
  try {
    corps = (await req.json()) as { source?: SourceReception };
  } catch {
    return NextResponse.json(
      { error: "Corps de requête JSON invalide." },
      { status: 400 }
    );
  }

  if (!corps.source || typeof corps.source !== "object") {
    return NextResponse.json(
      { error: "Source de création manquante." },
      { status: 400 }
    );
  }

  const { where, erreur } = await clauseSource(corps.source);
  if (erreur) {
    return NextResponse.json({ error: erreur }, { status: 400 });
  }

  try {
    const etiquettes = await db.labelRecord.findMany({
      ...(where ? { where } : {}),
      select: {
        of: true,
        modele: true,
        couleur: true,
        taille: true,
        manche: true,
        quantite: true,
      },
    });

    // Même regroupement que la création réelle (clé OF|modèle|couleur|taille|manche).
    const cles = new Set<string>();
    let attendu = 0;
    for (const e of etiquettes) {
      cles.add(`${e.of}|${e.modele}|${e.couleur}|${e.taille}|${e.manche}`);
      attendu += e.quantite;
    }

    return NextResponse.json(
      {
        etiquettes: etiquettes.length,
        lignes: cles.size,
        attendu,
      },
      { headers: { "Cache-Control": "no-store" } }
    );
  } catch (error) {
    console.error("Aperçu de réception impossible :", error);
    return NextResponse.json(
      { error: "Aperçu impossible (erreur serveur)." },
      { status: 500 }
    );
  }
}
