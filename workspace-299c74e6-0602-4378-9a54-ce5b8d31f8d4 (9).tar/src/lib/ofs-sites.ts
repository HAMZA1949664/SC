/**
 * Attribution des N° d'OF aux sites générateurs — isolation des façonniers.
 *
 * Demande Clément Design : « je ne veux pas que Archipel voie les OF générés
 * par NASSTEX, et le contraire aussi. » Les OF naissent à la génération
 * d'étiquettes : le site du compte connecté (NASSTEX, Archipel, France…) est
 * mémorisé pour chaque OF dans ce fichier JSON côté serveur (jamais envoyé au
 * navigateur), sur le modèle de cloud.config.json.
 *
 * Règles :
 *  - un OF peut avoir été généré par plusieurs sites (liste de sites) ;
 *  - un façonnier ne voit (liste des OF, détail, création d'export) que les
 *    OF dont la liste contient SON site — les comptes France (achats, stock)
 *    voient tout ;
 *  - un OF sans attribution connue (données antérieures à cette carte) reste
 *    visible des comptes France uniquement ;
 *  - au premier lancement (fichier absent), la carte est auto-amorcée depuis
 *    la file cloud locale : les payloads « label_generations » portent déjà
 *    site_id + of (qui a généré quoi).
 *
 * Tolérance : aucune fonction ne lève d'exception — en cas de problème de
 * lecture, la carte est retombée vide et reconstruite (jamais bloquant).
 */

import { readFile, rename, writeFile } from "node:fs/promises";
import path from "node:path";

import { db } from "@/lib/db";

const NOM_FICHIER = "ofs-sites.json";
const DUREE_CACHE_MS = 5_000;

/** Un OF et les sites qui l'ont généré. */
interface EntreeOf {
  sites: string[];
  /** Date de dernière mise à jour de l'entrée (info). */
  maj: string;
}

type CarteBrute = Record<string, EntreeOf>;

let cache: { valeur: CarteBrute; expire: number } | null = null;
let amorcageFait = false;

function cheminFichier(): string {
  return path.join(process.cwd(), NOM_FICHIER);
}

/** Un OF n'est mémorisé que s'il est numérique (cohérent avec les exports). */
function ofNumerique(of: string): boolean {
  return /^\d{1,20}$/.test(of);
}

/** Normalise une carte brute (tolérante aux entrées douteuses). */
function normaliser(brut: unknown): CarteBrute {
  const carte: CarteBrute = {};
  if (!brut || typeof brut !== "object") return carte;
  const ofs = (brut as { ofs?: unknown }).ofs ?? brut;
  if (!ofs || typeof ofs !== "object") return carte;
  for (const [of, entree] of Object.entries(ofs as Record<string, unknown>)) {
    if (!ofNumerique(of)) continue;
    const sites = Array.isArray((entree as EntreeOf | undefined)?.sites)
      ? [...new Set((entree as EntreeOf).sites.map((s) => String(s ?? "").trim()).filter(Boolean))]
      : [];
    if (sites.length === 0) continue;
    carte[of] = { sites, maj: String((entree as EntreeOf).maj ?? "") };
  }
  return carte;
}

/** Auto-amorçage : reconstruit la carte depuis la file cloud locale. */
async function amorcerDepuisFile(): Promise<CarteBrute> {
  if (amorcageFait) return {};
  amorcageFait = true;
  try {
    const lignes = await db.cloudSyncQueue.findMany({
      where: { table: "label_generations" },
      select: { payload: true },
    });
    const carte: CarteBrute = {};
    for (const l of lignes) {
      try {
        const p = JSON.parse(l.payload) as { of?: unknown; site_id?: unknown };
        const of = typeof p.of === "string" ? p.of.trim() : "";
        const site = typeof p.site_id === "string" ? p.site_id.trim() : "";
        if (!ofNumerique(of) || !site) continue;
        (carte[of] ??= { sites: [], maj: "" }).sites.push(site);
      } catch {
        // payload illisible : on ignore cette ligne
      }
    }
    for (const [of, e] of Object.entries(carte)) {
      e.sites = [...new Set(e.sites)];
      e.maj = new Date().toISOString();
    }
    if (Object.keys(carte).length > 0) {
      await ecrireCarte(carte);
      console.info(
        `${NOM_FICHIER} absent : carte auto-amorcée depuis la file cloud (${Object.keys(carte).length} OF).`
      );
    }
    return carte;
  } catch (error) {
    console.error("Amorçage de la carte OF/sites impossible :", error);
    return {};
  }
}

/** Écriture atomique (fichier temporaire + rename) — ne lève pas d'exception. */
async function ecrireCarte(carte: CarteBrute): Promise<void> {
  const contenu = {
    _lisezmoi:
      "CARTE D'ATTRIBUTION DES N° D'OF — quel site (façonnier / France) a généré chaque OF. " +
      "Fichier serveur (jamais envoyé au navigateur), mis à jour automatiquement à chaque génération " +
      "d'étiquettes. Un façonnier ne voit que les OF de son site ; les comptes France voient tout.",
    ofs: carte,
  };
  try {
    const tmp = `${cheminFichier()}.tmp`;
    await writeFile(tmp, JSON.stringify(contenu, null, 2) + "\n", "utf8");
    await rename(tmp, cheminFichier());
    cache = { valeur: carte, expire: Date.now() + DUREE_CACHE_MS };
  } catch (error) {
    console.error("Écriture de la carte OF/sites impossible :", error);
  }
}

/**
 * Lit la carte OF → sites (cache 5 s). Si le fichier est absent, tente un
 * amorçage depuis la file cloud locale. Ne lève jamais d'exception.
 */
export async function lireSitesParOf(): Promise<Map<string, string[]>> {
  if (cache && cache.expire > Date.now()) {
    return new Map(Object.entries(cache.valeur).map(([of, e]) => [of, e.sites]));
  }
  try {
    const brut = await readFile(cheminFichier(), "utf8");
    const carte = normaliser(JSON.parse(brut));
    cache = { valeur: carte, expire: Date.now() + DUREE_CACHE_MS };
    return new Map(Object.entries(carte).map(([of, e]) => [of, e.sites]));
  } catch {
    // Fichier absent (ou illisible) : amorçage une fois par process.
    const carte = await amorcerDepuisFile();
    return new Map(Object.entries(carte).map(([of, e]) => [of, e.sites]));
  }
}

/**
 * Enregistre le(s) site(s) générateur(s) d'un OF (ajout sans écrasement :
 * un OF généré par plusieurs sites reste visible des deux). Appelé à chaque
 * génération d'étiquettes — jamais bloquant.
 */
export async function attribuerOfsSite(ofs: string[], siteId: string): Promise<void> {
  const site = siteId.trim();
  const liste = [...new Set(ofs.map((o) => String(o ?? "").trim()).filter(ofNumerique))];
  if (!site || liste.length === 0) return;
  try {
    let carte: CarteBrute;
    try {
      carte = normaliser(JSON.parse(await readFile(cheminFichier(), "utf8")));
    } catch {
      carte = {};
    }
    const maj = new Date().toISOString();
    for (const of of liste) {
      const entree = carte[of];
      if (entree) {
        if (!entree.sites.includes(site)) {
          entree.sites = [...entree.sites, site];
          entree.maj = maj;
        }
      } else {
        carte[of] = { sites: [site], maj };
      }
    }
    await ecrireCarte(carte);
  } catch (error) {
    console.error("Attribution d'OF au site impossible :", error);
  }
}

/**
 * Filtre une liste d'OF pour un site donné : ne gardent que les OF dont la
 * carte contient CE site (isolation façonniers demandée par Clément Design).
 */
export async function ofsAutorisesPourSite(
  ofs: string[],
  siteId: string
): Promise<string[]> {
  const carte = await lireSitesParOf();
  return ofs.filter((of) => carte.get(of)?.includes(siteId) ?? false);
}
