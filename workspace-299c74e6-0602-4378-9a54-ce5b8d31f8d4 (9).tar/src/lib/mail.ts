/**
 * Mail de colisage aux achats — demande Clément Design :
 * « à chaque fois que le façonnier crée un export, envoyer les détails du
 * colisage aux achats par mail (tableau avec N° OF et le contenu de chaque OF
 * : article, manche, couleur, taille — et nombre de colis) » à
 * _achat@clementdesign.com.
 *
 * Fonctionnement :
 *  - déclenché côté serveur à la CRÉATION d'un export par un façonnier
 *    (POST /api/exports) — jamais bloquant : l'export est créé même si le
 *    mail échoue ;
 *  - la configuration SMTP vit dans mail.config.json (racine, même modèle que
 *    cloud.config.json : rechargé toutes les 5 s, editable sans redémarrage) ;
 *  - tant que le SMTP n'est pas renseigné (ou en cas d'échec d'envoi), le
 *    mail est mis en FILE dans mail-outbox.json et repartira automatiquement
 *    dès qu'un nouvel export sera créé avec un SMTP fonctionnel.
 *
 * Tolérance : aucune fonction ne lève d'exception — jamais d'impact sur la
 * création d'export.
 */

import { readFile, rename, writeFile } from "node:fs/promises";
import path from "node:path";

import nodemailer from "nodemailer";

const FICHIER_CONFIG = "mail.config.json";
const FICHIER_FILE = "mail-outbox.json";
const DUREE_CACHE_MS = 5_000;
/** Plafond de la file d'attente (les plus anciens sont écartés au-delà). */
const PLAFOND_FILE = 100;
/** Nombre maximal de mails de la file renvoyés à chaque occasion. */
const MAX_REPRISES_PAR_FLUX = 15;

/** Une ligne du tableau de colisage (déjà agrégée par l'export). */
export interface LigneColisage {
  of: string;
  modele: string;
  couleur: string;
  couleurCode: string;
  taille: string;
  manche: string;
  quantite: number;
}

/** Données du mail de colisage envoyé à la création d'un export. */
export interface EntreeMailColisage {
  titre: string;
  /** Date de départ du samedi (AAAA-MM-JJ). */
  dateExport: string;
  numeroColis: string;
  siteId: string;
  siteLabel: string;
  creeParNom: string;
  lignes: LigneColisage[];
  quantiteTotale: number;
}

interface ConfigMail {
  actif: boolean;
  destinataire: string;
  copies: string[];
  smtp: {
    hote: string;
    port: number;
    securise: boolean;
    utilisateur: string;
    motDePasse: string;
    expediteur: string;
  };
}

interface MailEnFile {
  date: string;
  destinataire: string;
  copies: string[];
  sujet: string;
  html: string;
  texte: string;
  tentatives: number;
  derniereErreur: string;
}

let cacheConfig: { valeur: ConfigMail; expire: number } | null = null;

function chemin(fichier: string): string {
  return path.join(process.cwd(), fichier);
}

/** Contenu initial du mail.config.json (créé automatiquement si absent). */
function configParDefaut(): string {
  return JSON.stringify(
    {
      _lisezmoi:
        "CONFIGURATION DU MAIL DE COLISAGE — envoyé aux achats à chaque export créé par un façonnier. " +
        "Remplissez smtp (hote, port, utilisateur, motDePasse) pour l'envoi réel : le fichier est relu " +
        "toutes les 5 secondes, sans redémarrage. Tant que utilisateur/motDePasse sont vides, les mails " +
        "sont mis en file dans mail-outbox.json et partiront automatiquement dès la configuration. " +
        "Exemple OVH : hote ssl0.ovh.net, port 587, securise false. Exemple Gmail : hote smtp.gmail.com, " +
        "port 587, securise false (mot de passe d'application requis).",
      actif: true,
      destinataire: "_achat@clementdesign.com",
      copies: [],
      smtp: {
        hote: "",
        port: 587,
        securise: false,
        utilisateur: "",
        motDePasse: "",
        expediteur: "",
      },
    },
    null,
    2
  ) + "\n";
}

/** Normalise une configuration douteuse (jamais d'exception). */
function normaliserConfig(brut: unknown): ConfigMail {
  const o = (brut ?? {}) as Record<string, unknown>;
  const smtp = (o.smtp ?? {}) as Record<string, unknown>;
  const port = Math.trunc(Number(smtp.port));
  const copies = Array.isArray(o.copies)
    ? o.copies.map((c) => String(c ?? "").trim()).filter(Boolean)
    : [];
  return {
    actif: o.actif !== false,
    destinataire: String(o.destinataire ?? "_achat@clementdesign.com").trim(),
    copies,
    smtp: {
      hote: String(smtp.hote ?? "").trim(),
      port: Number.isFinite(port) && port > 0 && port < 65536 ? port : 587,
      securise: smtp.securise === true,
      utilisateur: String(smtp.utilisateur ?? "").trim(),
      motDePasse: String(smtp.motDePasse ?? ""),
      expediteur: String(smtp.expediteur ?? "").trim(),
    },
  };
}

/** Lit la configuration (cache 5 s, création automatique si absente). */
async function lireConfigMail(): Promise<ConfigMail> {
  if (cacheConfig && cacheConfig.expire > Date.now()) return cacheConfig.valeur;
  try {
    const brut = await readFile(chemin(FICHIER_CONFIG), "utf8");
    const cfg = normaliserConfig(JSON.parse(brut));
    cacheConfig = { valeur: cfg, expire: Date.now() + DUREE_CACHE_MS };
    return cfg;
  } catch {
    // Absent/illisible : créer le modèle pour que Clément n'ait qu'à le
    // remplir, et repartir de la config par défaut.
    try {
      await writeFile(chemin(FICHIER_CONFIG), configParDefaut(), "utf8");
    } catch {
      // Best-effort : pas grave si l'écriture échoue.
    }
    const cfg = normaliserConfig(JSON.parse(configParDefaut()));
    cacheConfig = { valeur: cfg, expire: Date.now() + DUREE_CACHE_MS };
    return cfg;
  }
}

/** SMTP renseigné ? */
function estConfiguree(cfg: ConfigMail): boolean {
  return (
    cfg.actif &&
    cfg.smtp.hote.length > 0 &&
    cfg.smtp.utilisateur.length > 0 &&
    cfg.smtp.motDePasse.length > 0 &&
    cfg.destinataire.length > 0
  );
}

/** Échappement HTML des valeurs injectées dans le mail. */
function ech(s: string): string {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

/** Date AAAA-MM-JJ → JJ/MM/AAAA. */
function dateFr(iso: string): string {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso.trim());
  return m ? `${m[3]}/${m[2]}/${m[1]}` : iso;
}

/** Sujet du mail de colisage. */
function sujetColisage(e: EntreeMailColisage): string {
  return `Colisage — ${e.titre} — colis ${e.numeroColis} — départ samedi ${dateFr(e.dateExport)}`;
}

/** Corps HTML : fiche de colisage complète, groupée par OF. */
function htmlColisage(e: EntreeMailColisage, envoiLe: string): string {
  const th = 'style="border:1px solid #d4d4d8;padding:6px 10px;background:#fafaf9;text-align:left;font-size:13px"';
  const td = 'style="border:1px solid #e4e4e7;padding:6px 10px;font-size:13px"';
  const tdNum = 'style="border:1px solid #e4e4e7;padding:6px 10px;font-size:13px;text-align:right"';

  // Regroupement par OF (lignes sans OF → groupe « Hors OF » en dernier).
  const groupes: Array<{ of: string; lignes: LigneColisage[]; pieces: number }> = [];
  for (const l of e.lignes) {
    let g = groupes.find((x) => x.of === l.of);
    if (!g) {
      g = { of: l.of, lignes: [], pieces: 0 };
      groupes.push(g);
    }
    g.lignes.push(l);
    g.pieces += l.quantite;
  }
  groupes.sort((a, b) => {
    if (a.of === "" && b.of !== "") return 1;
    if (b.of === "" && a.of !== "") return -1;
    return a.of.localeCompare(b.of, "fr", { numeric: true });
  });

  const lignesHtml: string[] = [];
  for (const g of groupes) {
    const titreGroupe =
      g.of === ""
        ? "Hors OF (lignes ajoutées manuellement)"
        : `OF ${ech(g.of)}`;
    lignesHtml.push(
      `<tr><td colspan="6" style="border:1px solid #d4d4d8;padding:6px 10px;background:#f5f5f4;font-weight:bold;font-size:13px">${titreGroupe} — ${g.pieces} pièce${g.pieces > 1 ? "s" : ""}</td></tr>`
    );
    for (const l of g.lignes) {
      const couleur = l.couleurCode
        ? `${ech(l.couleur)} (${ech(l.couleurCode)})`
        : ech(l.couleur);
      lignesHtml.push(
        `<tr><td ${td}>${ech(l.of || "—")}</td><td ${td}>${ech(l.modele)}</td><td ${td}>${ech(l.manche || "—")}</td><td ${td}>${couleur}</td><td ${td}>${ech(l.taille)}</td><td ${tdNum}>${l.quantite}</td></tr>`
      );
    }
  }

  const infos: Array<[string, string]> = [
    ["Export", ech(e.titre)],
    ["Départ", `samedi ${ech(dateFr(e.dateExport))}`],
    ["N° de colis", ech(e.numeroColis)],
    ["Nombre de colis", "1"],
    ["Usine (façonnier)", `${ech(e.siteLabel)}${e.creeParNom && !e.siteLabel.includes(e.creeParNom) ? ` — ${ech(e.creeParNom)}` : ""}`],
    [
      "OF concernés",
      e.lignes
        .map((l) => l.of)
        .filter((o, i, t) => o !== "" && t.indexOf(o) === i)
        .map((o) => ech(o))
        .join(", ") || "—",
    ],
    ["Total", `${e.lignes.length} ligne${e.lignes.length > 1 ? "s" : ""} — ${e.quantiteTotale} pièce${e.quantiteTotale > 1 ? "s" : ""}`],
  ];

  return `<div style="font-family:Arial,Helvetica,sans-serif;max-width:760px;color:#18181b">
  <h2 style="margin:0 0 4px;font-size:20px">📦 Fiche de colisage — nouvel export</h2>
  <p style="margin:0 0 16px;color:#71717a;font-size:13px">Créé le ${ech(envoiLe)} — envoyé automatiquement par l'application Étiquettes &amp; colisage.</p>
  <table style="border-collapse:collapse;width:100%;margin-bottom:20px">
    ${infos.map(([k, v]) => `<tr><td ${th} width="170">${k}</td><td ${td}>${v}</td></tr>`).join("\n    ")}
  </table>
  <h3 style="margin:0 0 8px;font-size:15px">Détail du colis par OF</h3>
  <table style="border-collapse:collapse;width:100%">
    <thead><tr><th ${th}>N° OF</th><th ${th}>Article</th><th ${th}>Manche</th><th ${th}>Couleur</th><th ${th}>Taille</th><th ${th}>Qté</th></tr></thead>
    <tbody>
    ${lignesHtml.join("\n    ")}
    <tr><td colspan="5" style="border:1px solid #d4d4d8;padding:6px 10px;background:#fafaf9;font-weight:bold;font-size:13px;text-align:right">TOTAL</td><td ${tdNum}><b>${e.quantiteTotale}</b></td></tr>
    </tbody>
  </table>
</div>`;
}

/** Corps texte brut (clients sans HTML). */
function texteColisage(e: EntreeMailColisage, envoiLe: string): string {
  const groupes = new Map<string, LigneColisage[]>();
  for (const l of e.lignes) {
    const cle = l.of || "(hors OF)";
    const g = groupes.get(cle) ?? [];
    g.push(l);
    groupes.set(cle, g);
  }
  const blocs: string[] = [];
  for (const [of, lignes] of [...groupes.entries()].sort((a, b) =>
    a[0].localeCompare(b[0], "fr", { numeric: true })
  )) {
    const pieces = lignes.reduce((s, l) => s + l.quantite, 0);
    blocs.push(
      `— ${of} (${pieces} pièce${pieces > 1 ? "s" : ""})\n` +
        lignes
          .map(
            (l) =>
              `   · ${l.modele} · ${l.manche || "—"} · ${l.couleur}${l.couleurCode ? ` (${l.couleurCode})` : ""} · ${l.taille} → ${l.quantite}`
          )
          .join("\n")
    );
  }
  return [
    `FICHE DE COLISAGE — NOUVEL EXPORT`,
    ``,
    `Export : ${e.titre}`,
    `Départ : samedi ${dateFr(e.dateExport)}`,
    `N° de colis : ${e.numeroColis}`,
    `Nombre de colis : 1`,
    `Usine : ${e.siteLabel}${e.creeParNom ? ` — ${e.creeParNom}` : ""}`,
    `Créé le : ${envoiLe}`,
    ``,
    `DÉTAIL PAR OF :`,
    ...blocs,
    ``,
    `TOTAL : ${e.lignes.length} ligne(s) — ${e.quantiteTotale} pièce(s)`,
    ``,
    `(mail automatique — application Étiquettes & colisage)`,
  ].join("\n");
}

/** Lecture tolérante de la file d'attente. */
async function lireFile(): Promise<MailEnFile[]> {
  try {
    const brut = JSON.parse(await readFile(chemin(FICHIER_FILE), "utf8"));
    return Array.isArray(brut?.mails) ? (brut.mails as MailEnFile[]) : [];
  } catch {
    return [];
  }
}

/** Écriture atomique de la file (jamais d'exception). */
async function ecrireFile(mails: MailEnFile[]): Promise<void> {
  try {
    const contenu = {
      _lisezmoi:
        "FILE D'ATTENTE DES MAILS DE COLISAGE — mails créés tant que le SMTP de mail.config.json est vide (ou en échec). Ils repartent automatiquement dès qu'un SMTP fonctionne.",
      mails: mails.slice(-PLAFOND_FILE),
    };
    const tmp = `${chemin(FICHIER_FILE)}.tmp`;
    await writeFile(tmp, JSON.stringify(contenu, null, 2) + "\n", "utf8");
    await rename(tmp, chemin(FICHIER_FILE));
  } catch (error) {
    console.error("Écriture de la file de mails impossible :", error);
  }
}

/** Envoi réel via le SMTP configuré. */
async function envoyer(
  cfg: ConfigMail,
  destinataire: string,
  copies: string[],
  sujet: string,
  html: string,
  texte: string
): Promise<void> {
  const transporteur = nodemailer.createTransport({
    host: cfg.smtp.hote,
    port: cfg.smtp.port,
    secure: cfg.smtp.securise,
    auth: { user: cfg.smtp.utilisateur, pass: cfg.smtp.motDePasse },
    connectionTimeout: 15_000,
    greetingTimeout: 15_000,
    socketTimeout: 20_000,
  });
  await transporteur.sendMail({
    from: cfg.smtp.expediteur || cfg.smtp.utilisateur,
    to: destinataire,
    cc: copies.length > 0 ? copies : undefined,
    subject: sujet,
    text: texte,
    html,
  });
}

/** Reprend (une fois) les mails en file si le SMTP est maintenant opérationnel. */
async function reprendreFile(cfg: ConfigMail): Promise<void> {
  if (!estConfiguree(cfg)) return;
  const file = await lireFile();
  if (file.length === 0) return;
  const restants: MailEnFile[] = [];
  let envoyes = 0;
  for (const mail of file.slice(-MAX_REPRISES_PAR_FLUX)) {
    try {
      await envoyer(cfg, mail.destinataire, mail.copies, mail.sujet, mail.html, mail.texte);
      envoyes += 1;
    } catch (error) {
      restants.push({
        ...mail,
        tentatives: mail.tentatives + 1,
        derniereErreur: error instanceof Error ? error.message : String(error),
      });
    }
  }
  await ecrireFile(restants);
  if (envoyes > 0) {
    console.info(`Mail colisage : ${envoyes} mail(s) en file envoyé(s) aux achats.`);
  }
}

/**
 * Prépare et envoie le mail de colisage d'un export créé par un façonnier.
 * Jamais bloquant : tout échec met le mail en file (mail-outbox.json).
 */
export async function envoyerMailColisageExport(
  entree: EntreeMailColisage
): Promise<void> {
  try {
    const cfg = await lireConfigMail();
    if (!cfg.actif || cfg.destinataire.length === 0) return;

    const envoiLe = new Intl.DateTimeFormat("fr-FR", {
      timeZone: "Europe/Paris",
      dateStyle: "short",
      timeStyle: "short",
    }).format(new Date());
    const sujet = sujetColisage(entree);
    const html = htmlColisage(entree, envoiLe);
    const texte = texteColisage(entree, envoiLe);

    // D'abord : reprise des mails restés en file (si SMTP désormais prêt).
    await reprendreFile(cfg);

    if (estConfiguree(cfg)) {
      try {
        await envoyer(cfg, cfg.destinataire, cfg.copies, sujet, html, texte);
        console.info(
          `Mail colisage envoyé aux achats (${cfg.destinataire}) — export « ${entree.titre} », colis ${entree.numeroColis}.`
        );
        return;
      } catch (error) {
        console.error(
          "Envoi du mail de colisage impossible — mis en file :",
          error instanceof Error ? error.message : error
        );
      }
    } else {
      console.info(
        "SMTP du mail.config.json non renseigné — mail de colisage mis en file (partira dès la configuration)."
      );
    }

    const file = await lireFile();
    file.push({
      date: new Date().toISOString(),
      destinataire: cfg.destinataire,
      copies: cfg.copies,
      sujet,
      html,
      texte,
      tentatives: 0,
      derniereErreur: "",
    });
    await ecrireFile(file);
  } catch (error) {
    // Absolument jamais bloquant pour la création d'export.
    console.error("Mail de colisage (erreur inattendue, ignorée) :", error);
  }
}
