/**
 * Exports façonnier — types et helpers partagés client/serveur.
 *
 * Principe (sans modification de la structure de la base) : un « export »
 * (marchandise expédiée par le façonnier un samedi) est enregistré dans les
 * tables existantes Réception / RéceptionLigne. La métadonnée export (date du
 * samedi, numéro de colis, site expéditeur…) est sérialisée dans le champ
 * `note` de la réception, préfixé par un marqueur — lisible uniquement par
 * l'application, invisible pour les usages classiques des réceptions.
 *
 * Flux demandé par Clément Design :
 *  1. Nouvel export : l'utilisateur choisit un N° d'OF déjà généré → toutes
 *     les informations (articles, codes-barres, quantités, couleurs, tailles)
 *     sont récupérées automatiquement, rien à ressaisir ;
 *  2. « Ajouter une ligne » : possibilité secondaire d'ajouter manuellement
 *     une ligne hors OF ;
 *  3. Colisage : la seule information nouvelle à saisir est le n° de colis ;
 *  4. Date : les exports partent le samedi — on propose les deux prochains
 *     samedis.
 */

/** Marqueur placé en tête du champ `note` pour identifier un export. */
export const MARQUEUR_EXPORT = "EXPORT|";

/** Métadonnée d'un export (sérialisée dans Reception.note). */
export interface MetaExport {
  v: 1;
  /** Date de l'export (samedi), format AAAA-MM-JJ (Europe/Paris). */
  dateExport: string;
  /** Numéro de colis (colisage) — seule saisie nouvelle demandée. */
  numeroColis: string;
  /** Site expéditeur (façonnier) au moment de la création. */
  siteId: string;
  siteLabel: string;
  /** Compte créateur. */
  creePar: string;
  creeParNom: string;
  /** OF(s) automatiquement repris ([] si seulement des lignes manuelles). */
  ofs: string[];
}

/** Sérialise la métadonnée pour le champ `note`. */
export function encoderMetaExport(meta: MetaExport): string {
  return MARQUEUR_EXPORT + JSON.stringify(meta);
}

/** Tente de lire la métadonnée export d'une note. Retourne null sinon. */
export function lireMetaExport(note: string | null | undefined): MetaExport | null {
  if (!note || !note.startsWith(MARQUEUR_EXPORT)) return null;
  try {
    const brut = JSON.parse(note.slice(MARQUEUR_EXPORT.length)) as Partial<MetaExport>;
    if (
      brut &&
      typeof brut.dateExport === "string" &&
      typeof brut.numeroColis === "string" &&
      typeof brut.siteId === "string"
    ) {
      return {
        v: 1,
        dateExport: brut.dateExport,
        numeroColis: brut.numeroColis,
        siteId: brut.siteId,
        siteLabel: brut.siteLabel ?? "",
        creePar: brut.creePar ?? "",
        creeParNom: brut.creeParNom ?? "",
        ofs: Array.isArray(brut.ofs) ? brut.ofs.map(String) : [],
      };
    }
    return null;
  } catch {
    return null;
  }
}

// ---------------------------------------------------------------------------
// Samedis d'export + semaine ISO (fuseau Europe/Paris)
// ---------------------------------------------------------------------------

/** Date « aujourd'hui » en Europe/Paris, au format AAAA-MM-JJ. */
export function aujourdhuiParis(): string {
  // fr-CA donne AAAA-MM-JJ (format ISO) — stable pour ce usage.
  return new Intl.DateTimeFormat("fr-CA", {
    timeZone: "Europe/Paris",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(new Date());
}

/** Jour de la semaine d'une date AAAA-MM-JJ (0 = dimanche … 6 = samedi). */
function jourSemaine(iso: string): number {
  const [a, m, j] = iso.split("-").map(Number);
  // Midi UTC : évite tout décalage de fuseau sur le calendrier pur.
  return new Date(Date.UTC(a, m - 1, j, 12)).getUTCDay();
}

/** Vrai si la date AAAA-MM-JJ est un samedi. */
export function estSamedi(iso: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(iso)) return false;
  return jourSemaine(iso) === 6;
}

/**
 * Les `n` prochains samedis (aujourd'hui inclus s'il est samedi — l'expédition
 * peut partir le jour même). Retourne des dates AAAA-MM-JJ.
 */
export function prochainsSamedis(n = 2, aujourdhui = aujourdhuiParis()): string[] {
  const [a, m, j] = aujourdhui.split("-").map(Number);
  const base = new Date(Date.UTC(a, m - 1, j, 12));
  const ecart = (6 - base.getUTCDay() + 7) % 7; // jours jusqu'au samedi (0 si samedi)
  const samedis: string[] = [];
  for (let i = 0; i < n; i += 1) {
    const d = new Date(base.getTime() + (ecart + i * 7) * 86_400_000);
    samedis.push(
      `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, "0")}-${String(
        d.getUTCDate()
      ).padStart(2, "0")}`
    );
  }
  return samedis;
}

/** N° de semaine ISO 8601 d'une date AAAA-MM-JJ (le samedi porte sa semaine). */
export function semaineIso(iso: string): number {
  const [a, m, j] = iso.split("-").map(Number);
  const d = new Date(Date.UTC(a, m - 1, j, 12));
  // Jeudi de la même semaine ISO (lundi → dimanche).
  const jour = d.getUTCDay() || 7;
  d.setUTCDate(d.getUTCDate() + 4 - jour);
  const debutAnnee = new Date(Date.UTC(d.getUTCFullYear(), 0, 1, 12));
  return Math.ceil(((d.getTime() - debutAnnee.getTime()) / 86_400_000 + 1) / 7);
}

/** Format lisible : « samedi 26/09/2026 ». */
export function formaterSamedi(iso: string): string {
  const [a, m, j] = iso.split("-");
  return `samedi ${j}/${m}/${a}`;
}

/** Nom court d'un site : « Tunisie — NASSTEX » → « NASSTEX ». */
export function nomCourtSite(siteLabel: string): string {
  const idx = siteLabel.indexOf("—");
  const court = idx >= 0 ? siteLabel.slice(idx + 1) : siteLabel;
  return court.trim() || siteLabel.trim() || "Façonnier";
}

// ---------------------------------------------------------------------------
// Types d'API
// ---------------------------------------------------------------------------

/** Une ligne d'export (automatique depuis un OF, ou saisie manuellement). */
export interface LigneExport {
  of: string;
  modele: string;
  couleur: string;
  couleurCode: string;
  taille: string;
  manche: string;
  /** Quantité de pièces (copies comprises). */
  quantite: number;
  /** Codes-barres de la ligne (aperçu, plafonné — info automatique OF). */
  codes?: string[];
}

/** OF déjà généré, proposé dans la liste de sélection du nouvel export. */
export interface OfDisponible {
  of: string;
  /** Nombre d'étiquettes (lignes de codes) de cet OF. */
  nbEtiquettes: number;
  /** Total des pièces (somme des quantités). */
  pieces: number;
  /** Date de la dernière génération de cet OF. */
  dernierAt: string;
}

/** Export de la liste GET /api/exports. */
export interface ExportListe {
  id: string;
  titre: string;
  statut: string;
  dateExport: string;
  numeroColis: string;
  siteId: string;
  siteLabel: string;
  creeParNom: string;
  creeAt: string;
  lignes: LigneExport[];
  quantiteTotale: number;
}

/** Corps de POST /api/exports. */
export interface CorpsCreationExport {
  /** Titre optionnel — auto : « Export semaine N — {site} ». */
  titre?: string;
  /** Samedi choisi (AAAA-MM-JJ) parmi les deux prochains samedis proposés. */
  dateExport: string;
  /** Numéro de colis (seule saisie nouvelle du colisage). */
  numeroColis: string;
  /** OF déjà généré : toutes ses lignes sont récupérées automatiquement. */
  of?: string;
  /** Plusieurs OF déjà générés (parfois 3, 5, 8 OF par export) : toutes
   *  leurs lignes sont récupérées et regroupées automatiquement. */
  ofs?: string[];
  /** Lignes manuelles (« Ajouter une ligne »). */
  lignesManuelles?: {
    of?: string;
    article: string;
    couleur?: string;
    taille?: string;
    manche?: string;
    quantite: number;
  }[];
}
